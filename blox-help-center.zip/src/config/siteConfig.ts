/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Official Deployment Configuration for BLOX Help Centre.
 * Public customer-support portal — no customer login or account required.
 * Visitors cannot modify these settings in the browser.
 */

const env = import.meta.env;

function isValidHttpUrl(value: string | undefined): value is string {
  if (!value) return false;
  return value.startsWith('https://') || value.startsWith('http://');
}

function isValidEmail(value: string | undefined): value is string {
  if (!value) return false;
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
}

export const APP_LINKS = {
  APP_NAME: 'BLOX: Stop Doomscrolling',
  APP_STORE_URL: 'https://apps.apple.com/us/app/blox-stop-doomscrolling/id6808123384',
  PLAY_STORE_STATUS: 'COMING_SOON' as const,
  PLAY_STORE_URL: null as string | null,
};

const OFFICIAL_GOOGLE_FORM_DIRECT_URL =
  'https://docs.google.com/forms/d/e/1FAIpQLScAtNcrv_BVaUiqZafikTBaxm_qqhXdI7_rGjGBY3FS2P11rg/viewform';
const OFFICIAL_GOOGLE_FORM_EMBED_URL =
  'https://docs.google.com/forms/d/e/1FAIpQLScAtNcrv_BVaUiqZafikTBaxm_qqhXdI7_rGjGBY3FS2P11rg/viewform?embedded=true';

const RAW_SUPPORT_EMAIL = env.VITE_BLOX_SUPPORT_EMAIL || 'blox.workspace@gmail.com';
const RAW_WHATSAPP_CHANNEL_URL =
  env.VITE_BLOX_WHATSAPP_CHANNEL_URL || 'https://whatsapp.com/channel/0029Vb98wGF1NCrNtavTQ910';
const RAW_GOOGLE_FORM_DIRECT_URL =
  env.VITE_BLOX_FEEDBACK_FORM_URL || OFFICIAL_GOOGLE_FORM_DIRECT_URL;
const RAW_GOOGLE_FORM_EMBED_URL =
  env.VITE_BLOX_FEEDBACK_FORM_EMBED_URL || OFFICIAL_GOOGLE_FORM_EMBED_URL;

export const SITE_CONFIG = {
  // Official Support Email
  supportEmail: RAW_SUPPORT_EMAIL,
  isSupportEmailConfigured: isValidEmail(RAW_SUPPORT_EMAIL),

  // Official WhatsApp Channel (announcements & updates — not a direct support chat)
  whatsappChannelUrl: RAW_WHATSAPP_CHANNEL_URL,
  isWhatsappChannelConfigured: isValidHttpUrl(RAW_WHATSAPP_CHANNEL_URL),

  // Official Google Feedback Form URLs
  googleFeedbackFormName: 'BLOX Customer Feedback',
  googleFeedbackFormDirectUrl: RAW_GOOGLE_FORM_DIRECT_URL,
  googleFeedbackFormEmbedUrl: RAW_GOOGLE_FORM_EMBED_URL,
  isGoogleFormConfigured:
    isValidHttpUrl(RAW_GOOGLE_FORM_DIRECT_URL) && isValidHttpUrl(RAW_GOOGLE_FORM_EMBED_URL),
  isGoogleFormDirectConfigured: isValidHttpUrl(RAW_GOOGLE_FORM_DIRECT_URL),

  // Centralized Mobile App Store Links & Status
  iosAppName: APP_LINKS.APP_NAME,
  iosAppStoreUrl: APP_LINKS.APP_STORE_URL,
  isIosAppStoreConfigured: isValidHttpUrl(APP_LINKS.APP_STORE_URL),

  androidPlayStoreStatus: APP_LINKS.PLAY_STORE_STATUS,
  androidPlayStoreUrl: APP_LINKS.PLAY_STORE_URL,
  isAndroidPlayStoreConfigured: false,
};
