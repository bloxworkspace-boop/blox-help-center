/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type PlatformType = 'all' | 'ios' | 'android';

export interface WalkthroughStep {
  id: number;
  stepNumber: string;
  title: string;
  subtitle: string;
  description: string;
  keyTakeaway: string;
  platforms: ('ios' | 'android')[];
  iosSpecifics?: string[];
  androidSpecifics?: string[];
}

export interface FaqItem {
  id: string;
  category: 'general' | 'device' | 'app' | 'sessions' | 'support';
  question: string;
  answer: string;
  keywords: string[];
  appStoreLinkLabel?: string;
  includeEmailAction?: boolean;
}

export interface TroubleshootingIssue {
  id: string;
  category: 'nfc' | 'setup' | 'blocking' | 'session' | 'other';
  title: string;
  summary: string;
  guidance: string[];
}
