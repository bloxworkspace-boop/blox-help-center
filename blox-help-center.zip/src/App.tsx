/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { ConfigProvider, useBloxConfig } from './context/ConfigContext';
import { Navbar } from './components/Navbar';
import { Home } from './components/Home';
import { Walkthrough } from './components/Walkthrough';
import { FAQs } from './components/FAQs';
import { Troubleshooting } from './components/Troubleshooting';
import { ContactSupport } from './components/ContactSupport';
import { FeedbackReviews } from './components/FeedbackReviews';
import { Footer } from './components/Footer';

const PortalMainContent: React.FC = () => {
  const { activeSection } = useBloxConfig();

  return (
    <main
      id="main-content"
      tabIndex={-1}
      className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 min-h-[calc(100vh-18rem)] scroll-mt-[88px] focus:outline-none"
    >
      {activeSection === 'home' && <Home />}
      {activeSection === 'walkthrough' && <Walkthrough />}
      {activeSection === 'faqs' && <FAQs />}
      {activeSection === 'troubleshooting' && <Troubleshooting />}
      {activeSection === 'support' && <ContactSupport />}
      {activeSection === 'feedback' && <FeedbackReviews />}
    </main>
  );
};

export default function App() {
  return (
    <ConfigProvider>
      <div className="min-h-screen bg-[#090A0C] text-[#F5F5F5] flex flex-col font-sans selection:bg-[#F4510B] selection:text-white">
        <Navbar />
        <div className="flex-1">
          <PortalMainContent />
        </div>
        <Footer />
      </div>
    </ConfigProvider>
  );
}
