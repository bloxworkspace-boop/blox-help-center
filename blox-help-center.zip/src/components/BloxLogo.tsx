/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';

interface BloxLogoProps {
  className?: string;
}

/**
 * Official BLOX circular emblem component.
 * Uses the authoritative transparent PNG directly with preserved aspect ratio,
 * no clipping, no background fill, and no CSS filters or distortions.
 */
export const BloxLogo: React.FC<BloxLogoProps> = ({ className = 'w-10 h-10' }) => {
  return (
    <img
      src="/assets/blox-logo-circular.png"
      alt="BLOX logo"
      className={`inline-block shrink-0 aspect-square object-contain select-none ${className}`}
      draggable={false}
    />
  );
};
