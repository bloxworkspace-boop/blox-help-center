/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { useBloxConfig, NavSection, SECTION_HASHES } from '../context/ConfigContext';
import { BloxLogo } from './BloxLogo';
import { Menu, X } from 'lucide-react';

const NAV_ITEMS: { id: NavSection; label: string }[] = [
  { id: 'home', label: 'Home' },
  { id: 'walkthrough', label: 'How to Use BLOX' },
  { id: 'faqs', label: 'FAQs' },
  { id: 'troubleshooting', label: 'Troubleshooting' },
  { id: 'support', label: 'Contact Support' },
  { id: 'feedback', label: 'Feedback & Reviews' },
];

export const Navbar: React.FC = () => {
  const { activeSection, setActiveSection } = useBloxConfig();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const menuButtonRef = useRef<HTMLButtonElement>(null);
  const mobileDialogRef = useRef<HTMLDivElement>(null);
  const mobileCloseButtonRef = useRef<HTMLButtonElement>(null);

  const handleLinkClick = (
    event: React.MouseEvent<HTMLAnchorElement>,
    id: NavSection,
    fromMobileMenu = false
  ) => {
    event.preventDefault();
    setActiveSection(id);
    if (fromMobileMenu) {
      setMobileMenuOpen(false);
      requestAnimationFrame(() => {
        document.getElementById('main-content')?.focus({ preventScroll: true });
      });
    }
  };

  const closeMobileMenuAndRestoreFocus = () => {
    setMobileMenuOpen(false);
    requestAnimationFrame(() => {
      menuButtonRef.current?.focus();
    });
  };

  // Focus management, Tab focus trap, Escape handling, and body scroll lock for mobile drawer
  useEffect(() => {
    if (!mobileMenuOpen) {
      document.body.style.overflow = '';
      return;
    }

    document.body.style.overflow = 'hidden';

    // Move focus into the mobile navigation dialog when opened
    const focusTimer = requestAnimationFrame(() => {
      mobileCloseButtonRef.current?.focus();
    });

    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        event.preventDefault();
        closeMobileMenuAndRestoreFocus();
        return;
      }

      if (event.key === 'Tab' && mobileDialogRef.current) {
        const focusable = mobileDialogRef.current.querySelectorAll<HTMLElement>(
          'a[href], button:not([disabled]), [tabindex]:not([tabindex="-1"])'
        );
        if (focusable.length === 0) return;

        const firstEl = focusable[0];
        const lastEl = focusable[focusable.length - 1];

        if (event.shiftKey && document.activeElement === firstEl) {
          event.preventDefault();
          lastEl.focus();
        } else if (!event.shiftKey && document.activeElement === lastEl) {
          event.preventDefault();
          firstEl.focus();
        } else if (!mobileDialogRef.current.contains(document.activeElement)) {
          event.preventDefault();
          firstEl.focus();
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => {
      cancelAnimationFrame(focusTimer);
      document.body.style.overflow = '';
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [mobileMenuOpen]);

  return (
    <>
      <header className="sticky top-0 z-50 w-full bg-[#090A0C]/95 backdrop-blur-md border-b border-white/[0.08]">
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 xl:px-12">
          <div className="flex items-center justify-between gap-6 h-[72px] lg:h-[80px] min-w-0">

            {/* Brand Lockup (Left) */}
            <a
              href={SECTION_HASHES.home}
              onClick={(e) => handleLinkClick(e, 'home', mobileMenuOpen)}
              aria-label="BLOX Help Centre Home"
              className="flex items-center gap-3 shrink-0 text-left group focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#F4510B]/80 focus-visible:ring-offset-2 focus-visible:ring-offset-[#090A0C] rounded-lg"
            >
              <BloxLogo className="w-[38px] h-[38px] lg:w-[42px] lg:h-[42px]" />
              <span className="flex flex-col leading-none">
                <span className="text-[17px] lg:text-[18px] font-bold tracking-[-0.02em] text-[#F5F5F5] group-hover:text-white transition-colors">
                  BLOX
                </span>
                <span className="mt-1 text-[9.5px] lg:text-[10px] font-semibold uppercase tracking-[0.18em] text-[#A1A1AA] whitespace-nowrap">
                  HELP CENTRE
                </span>
              </span>
            </a>

            {/* Primary Navigation Links (Desktop 1024px+) */}
            <nav
              aria-label="Primary navigation"
              className="hidden lg:flex items-center justify-end min-w-0"
            >
              <ul className="flex items-center gap-5 xl:gap-8">
                {NAV_ITEMS.map((item) => {
                  const isActive = activeSection === item.id;
                  return (
                    <li key={item.id} className="shrink-0">
                      <a
                        href={SECTION_HASHES[item.id]}
                        onClick={(e) => handleLinkClick(e, item.id)}
                        aria-current={isActive ? 'page' : undefined}
                        className={`relative inline-block py-2 px-0.5 text-[13px] xl:text-[14px] font-medium whitespace-nowrap transition-colors duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#F4510B]/80 focus-visible:ring-offset-2 focus-visible:ring-offset-[#090A0C] rounded-sm ${
                          isActive
                            ? 'text-[#F5F5F5]'
                            : 'text-[#A1A1AA] hover:text-[#F5F5F5]'
                        }`}
                      >
                        <span>{item.label}</span>
                        <span
                          aria-hidden="true"
                          className={`absolute left-0 right-0 -bottom-0.5 h-[2px] rounded-full bg-[#F4510B] transition-opacity duration-200 ${
                            isActive ? 'opacity-100' : 'opacity-0'
                          }`}
                        />
                      </a>
                    </li>
                  );
                })}
              </ul>
            </nav>

            {/* Hamburger Menu Button (Mobile & Tablet below 1024px) */}
            <button
              ref={menuButtonRef}
              type="button"
              onClick={() => {
                if (mobileMenuOpen) {
                  closeMobileMenuAndRestoreFocus();
                } else {
                  setMobileMenuOpen(true);
                }
              }}
              aria-label={mobileMenuOpen ? 'Close navigation menu' : 'Open navigation menu'}
              aria-expanded={mobileMenuOpen}
              aria-controls="mobile-navigation-panel"
              className="lg:hidden inline-flex items-center justify-center w-10 h-10 rounded-lg bg-[#17191D] hover:bg-white/[0.08] text-[#F5F5F5] border border-white/[0.08] transition-colors cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#F4510B] focus-visible:ring-offset-2 focus-visible:ring-offset-[#090A0C] shrink-0"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>

          </div>
        </div>
      </header>

      {/* Mobile & Tablet Navigation Drawer */}
      {mobileMenuOpen && (
        <div
          ref={mobileDialogRef}
          id="mobile-navigation-panel"
          role="dialog"
          aria-modal="true"
          aria-label="Mobile navigation menu"
          className="fixed inset-x-0 top-[72px] bottom-0 z-50 lg:hidden bg-[#090A0C] border-t border-white/[0.08] overflow-y-auto"
        >
          <div className="max-w-xl mx-auto px-5 py-6 space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-white/[0.08]">
              <span className="text-xs font-semibold uppercase tracking-wider text-[#A1A1AA]">
                Navigation
              </span>
              <button
                ref={mobileCloseButtonRef}
                type="button"
                onClick={closeMobileMenuAndRestoreFocus}
                aria-label="Close navigation menu"
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#17191D] hover:bg-white/[0.08] border border-white/[0.08] text-xs font-medium text-[#F5F5F5] cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#F4510B]"
              >
                <X className="w-4 h-4" />
                <span>Close</span>
              </button>
            </div>

            <nav aria-label="Mobile navigation links" className="space-y-1.5">
              {NAV_ITEMS.map((item) => {
                const isActive = activeSection === item.id;
                return (
                  <a
                    key={item.id}
                    href={SECTION_HASHES[item.id]}
                    onClick={(e) => handleLinkClick(e, item.id, true)}
                    aria-current={isActive ? 'page' : undefined}
                    className={`w-full min-h-[48px] px-4 py-3 rounded-xl text-left text-[15px] font-medium flex items-center justify-between transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#F4510B] ${
                      isActive
                        ? 'text-[#F5F5F5] bg-[#17191D] border border-white/[0.08]'
                        : 'text-[#A1A1AA] hover:text-[#F5F5F5] hover:bg-white/[0.04]'
                    }`}
                  >
                    <span>{item.label}</span>
                    {isActive && (
                      <span
                        aria-hidden="true"
                        className="w-1.5 h-5 rounded-full bg-[#F4510B]"
                      />
                    )}
                  </a>
                );
              })}
            </nav>
          </div>
        </div>
      )}
    </>
  );
};
