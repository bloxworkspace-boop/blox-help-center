/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { useBloxConfig, SECTION_HASHES } from '../context/ConfigContext';
import { FAQS } from '../data/portalData';
import { SITE_CONFIG } from '../config/siteConfig';
import { AppleLogoIcon } from './AppDownloadButtons';
import {
  ChevronDown,
  HelpCircle,
  Search,
  Mail,
  ExternalLink,
} from 'lucide-react';

export const FAQs: React.FC = () => {
  const { setActiveSection, activeFaqId, setActiveFaqId } = useBloxConfig();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<
    'all' | 'general' | 'app' | 'sessions' | 'support'
  >('all');
  const [expandedIds, setExpandedIds] = useState<string[]>([
    'what-is-blox',
    'how-blox-works',
  ]);

  useEffect(() => {
    if (activeFaqId && !expandedIds.includes(activeFaqId)) {
      setExpandedIds((prev) => [...prev, activeFaqId]);
      setSelectedCategory('all');
    }
  }, [activeFaqId]);

  const categories = [
    { id: 'all', label: 'All Questions' },
    { id: 'general', label: 'General' },
    { id: 'app', label: 'Blocks App' },
    { id: 'sessions', label: 'Sessions' },
    { id: 'support', label: 'Support' },
  ];

  const toggleAccordion = (id: string) => {
    setActiveFaqId(null);
    setExpandedIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const filteredFaqs = FAQS.filter((faq) => {
    const matchesCategory =
      selectedCategory === 'all' || faq.category === selectedCategory;
    const matchesSearch =
      searchQuery.trim() === '' ||
      faq.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
      faq.answer.toLowerCase().includes(searchQuery.toLowerCase()) ||
      faq.keywords.some((k) =>
        k.toLowerCase().includes(searchQuery.toLowerCase())
      );
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="space-y-12 py-8 sm:py-12 max-w-4xl mx-auto">

      {/* Header */}
      <div className="text-center space-y-3">
        <div className="text-xs font-semibold uppercase tracking-[0.14em] text-[#F4510B]">
          Frequently Asked Questions
        </div>
        <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-[#F5F5F5] tracking-tight">
          FAQs
        </h1>
        <p className="text-[#A1A1AA] text-base sm:text-lg max-w-2xl mx-auto">
          Clear answers based on confirmed BLOX product details.
        </p>
      </div>

      {/* Search & Category Tabs */}
      <div className="space-y-4">
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-[#A1A1AA] pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search FAQs (e.g. 'NFC', 'Blocks', 'iPhone', 'Android')..."
            aria-label="Search FAQs"
            className="w-full pl-11 pr-16 py-3.5 rounded-xl bg-[#17191D] text-[#F5F5F5] placeholder-[#A1A1AA] border border-white/[0.08] focus:border-[#F4510B] focus:outline-none transition-colors text-sm sm:text-base"
          />
          {searchQuery && (
            <button
              type="button"
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-xs px-2.5 py-1 bg-white/[0.06] hover:bg-white/[0.12] text-[#A1A1AA] hover:text-[#F5F5F5] rounded-md transition-colors cursor-pointer"
            >
              Clear
            </button>
          )}
        </div>

        <div className="flex flex-wrap items-center justify-center gap-2">
          {categories.map((cat) => (
            <button
              key={cat.id}
              type="button"
              onClick={() => setSelectedCategory(cat.id as typeof selectedCategory)}
              className={`px-3.5 py-2 rounded-lg text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap ${
                selectedCategory === cat.id
                  ? 'bg-[#F4510B] text-[#F5F5F5]'
                  : 'bg-[#17191D] text-[#A1A1AA] hover:text-[#F5F5F5] border border-white/[0.08]'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>
      </div>

      {/* Collapsible FAQ List */}
      <div className="space-y-3">
        {filteredFaqs.length === 0 ? (
          <div className="text-center py-12 rounded-2xl blox-card space-y-3">
            <HelpCircle className="w-8 h-8 text-[#A1A1AA] mx-auto" />
            <div className="text-base font-semibold text-[#F5F5F5]">No matching answers found</div>
            <p className="text-xs text-[#A1A1AA] max-w-sm mx-auto">
              No answers matched &quot;{searchQuery}&quot;. Contact our support team directly for assistance.
            </p>
            <button
              type="button"
              onClick={() => setActiveSection('support')}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-[#F4510B] hover:bg-[#E04807] text-[#F5F5F5] text-xs font-semibold transition-colors cursor-pointer"
            >
              Contact Support
            </button>
          </div>
        ) : (
          filteredFaqs.map((faq) => {
            const isExpanded = expandedIds.includes(faq.id);
            return (
              <div
                key={faq.id}
                id={`faq-${faq.id}`}
                className={`rounded-2xl border transition-colors overflow-hidden bg-[#17191D] ${
                  isExpanded
                    ? 'border-[#F4510B]/40'
                    : 'border-white/[0.08] hover:border-white/20'
                }`}
              >
                <button
                  type="button"
                  onClick={() => toggleAccordion(faq.id)}
                  aria-expanded={isExpanded}
                  className="w-full p-5 sm:p-6 text-left flex items-center justify-between gap-4 focus:outline-none group cursor-pointer"
                >
                  <h3 className="text-base sm:text-lg font-semibold text-[#F5F5F5] group-hover:text-[#F4510B] transition-colors">
                    {faq.question}
                  </h3>

                  <div
                    className={`w-8 h-8 rounded-lg flex items-center justify-center bg-[#090A0C] border border-white/[0.08] text-[#A1A1AA] group-hover:text-[#F5F5F5] transition-transform duration-200 shrink-0 ${
                      isExpanded ? 'rotate-180 text-[#F5F5F5]' : ''
                    }`}
                  >
                    <ChevronDown className="w-4 h-4" />
                  </div>
                </button>

                {isExpanded && (
                  <div className="px-5 pb-6 sm:px-6 sm:pb-6 pt-3 text-sm text-[#A1A1AA] leading-relaxed border-t border-white/[0.08] space-y-3">
                    <p className="text-[#F5F5F5]/90">{faq.answer}</p>
                    {faq.appStoreLinkLabel && (
                      <div className="pt-1">
                        <a
                          href={SITE_CONFIG.iosAppStoreUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#F4510B] hover:bg-[#E04807] text-[#F5F5F5] text-xs font-semibold transition-colors whitespace-nowrap"
                        >
                          <AppleLogoIcon className="w-4 h-4 shrink-0" />
                          <span>{faq.appStoreLinkLabel}</span>
                          <ExternalLink className="w-3.5 h-3.5 shrink-0" />
                        </a>
                      </div>
                    )}
                    {faq.includeEmailAction && (
                      <div className="pt-1">
                        <a
                          href={`mailto:${SITE_CONFIG.supportEmail}`}
                          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#F4510B] hover:bg-[#E04807] text-[#F5F5F5] text-xs font-semibold transition-colors whitespace-nowrap"
                        >
                          <Mail className="w-4 h-4 shrink-0" />
                          <span>Send an Email</span>
                        </a>
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>

      {/* Support Banner */}
      <div className="p-6 sm:p-8 rounded-2xl blox-card flex flex-col sm:flex-row items-center justify-between gap-6">
        <div className="space-y-1 text-center sm:text-left">
          <h3 className="text-lg font-bold text-[#F5F5F5]">Contact BLOX Support</h3>
          <p className="text-xs sm:text-sm text-[#A1A1AA]">
            Email{' '}
            <a
              href={`mailto:${SITE_CONFIG.supportEmail}`}
              className="font-mono text-[#F5F5F5] hover:text-[#F4510B] underline underline-offset-4 transition-colors"
            >
              {SITE_CONFIG.supportEmail}
            </a>{' '}
            or visit the Contact Support page.
          </p>
        </div>
        <div className="flex flex-wrap items-center justify-center gap-3 shrink-0">
          <a
            href={`mailto:${SITE_CONFIG.supportEmail}`}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[#F4510B] hover:bg-[#E04807] text-[#F5F5F5] font-semibold text-xs sm:text-sm transition-colors whitespace-nowrap"
          >
            <Mail className="w-4 h-4" />
            <span>Send an Email</span>
          </a>
          <a
            href={SECTION_HASHES.support}
            onClick={(e) => {
              e.preventDefault();
              setActiveSection('support');
            }}
            className="px-4 py-2.5 rounded-xl bg-[#090A0C] hover:bg-white/[0.06] text-[#F5F5F5] font-medium text-xs sm:text-sm border border-white/[0.08] transition-colors whitespace-nowrap"
          >
            Contact Support
          </a>
        </div>
      </div>

    </div>
  );
};
