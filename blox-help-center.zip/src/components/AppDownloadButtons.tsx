/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { SITE_CONFIG } from '../config/siteConfig';
import { ExternalLink } from 'lucide-react';

export const AppleLogoIcon: React.FC<{ className?: string }> = ({ className = 'w-5 h-5' }) => (
  <svg
    viewBox="0 0 24 24"
    fill="currentColor"
    aria-hidden="true"
    className={className}
  >
    <path d="M16.365 1.43c0 1.14-.493 2.27-1.177 3.08-.744.9-1.99 1.57-2.987 1.57-.12 0-.23-.02-.3-.03-.01-.06-.04-.22-.04-.39 0-1.15.572-2.27 1.206-2.98.804-.94 2.142-1.64 3.248-1.68.03.13.05.28.05.43zm4.565 15.71c-.03.07-.463 1.58-1.518 3.12-.945 1.34-1.94 2.71-3.43 2.71-1.517 0-1.9-.88-3.63-.88-1.698 0-2.302.91-3.67.91-1.377 0-2.332-1.26-3.428-2.8-1.287-1.82-2.323-4.63-2.323-7.28 0-4.28 2.797-6.55 5.552-6.55 1.448 0 2.675.95 3.6.95.865 0 2.222-1.01 3.902-1.01.613 0 2.886.06 4.374 2.19-.13.09-2.383 1.37-2.383 4.19 0 3.26 2.854 4.42 2.955 4.45z" />
  </svg>
);

export const GooglePlayLogoIcon: React.FC<{ className?: string }> = ({ className = 'w-5 h-5' }) => (
  <svg
    viewBox="0 0 24 24"
    fill="none"
    aria-hidden="true"
    className={className}
  >
    <path
      d="M3.609 1.814L13.792 12 3.61 22.186a1.73 1.73 0 0 1-.464-1.186V3c0-.461.175-.876.463-1.186z"
      fill="currentColor"
      fillOpacity="0.85"
    />
    <path
      d="M17.213 8.58l-3.42 3.42 3.42 3.42 3.868-2.202c.775-.44.775-1.996 0-2.436L17.213 8.58z"
      fill="currentColor"
      fillOpacity="0.55"
    />
    <path
      d="M13.792 12L3.609 1.814a1.69 1.69 0 0 1 1.711-.19l11.893 6.956L13.792 12z"
      fill="currentColor"
      fillOpacity="0.7"
    />
    <path
      d="M3.609 22.186L13.792 12l3.421 3.42-11.893 6.956a1.69 1.69 0 0 1-1.711-.19z"
      fill="currentColor"
      fillOpacity="0.4"
    />
  </svg>
);

interface AppStoreButtonProps {
  variant?: 'default' | 'compact';
  className?: string;
}

export const AppStoreDownloadButton: React.FC<AppStoreButtonProps> = ({
  variant = 'default',
  className = '',
}) => {
  if (variant === 'compact') {
    return (
      <a
        href={SITE_CONFIG.iosAppStoreUrl}
        target="_blank"
        rel="noopener noreferrer"
        className={`w-full flex items-center justify-between gap-3 px-3.5 py-2.5 rounded-xl bg-[#17191D] hover:bg-[#F4510B] text-[#F5F5F5] border border-white/[0.08] hover:border-[#F4510B] transition-colors duration-200 group ${className}`}
      >
        <div className="flex items-center gap-2.5 min-w-0">
          <AppleLogoIcon className="w-4 h-4 text-[#F5F5F5] shrink-0" />
          <div className="min-w-0">
            <div className="text-xs font-semibold text-[#F5F5F5] truncate">
              Download on the App Store
            </div>
            <div className="text-[11px] text-[#A1A1AA] group-hover:text-white/85 truncate transition-colors">
              {SITE_CONFIG.iosAppName}
            </div>
          </div>
        </div>
        <ExternalLink className="w-3.5 h-3.5 text-[#A1A1AA] group-hover:text-white shrink-0 transition-colors" />
      </a>
    );
  }

  return (
    <a
      href={SITE_CONFIG.iosAppStoreUrl}
      target="_blank"
      rel="noopener noreferrer"
      className={`inline-flex items-center justify-between gap-3.5 px-5 py-3.5 rounded-xl bg-[#F4510B] hover:bg-[#E04807] text-[#F5F5F5] font-semibold transition-colors duration-200 group focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white/80 focus-visible:ring-offset-2 focus-visible:ring-offset-[#090A0C] ${className}`}
    >
      <div className="flex items-center gap-3 min-w-0">
        <AppleLogoIcon className="w-6 h-6 text-[#F5F5F5] shrink-0" />
        <div className="flex flex-col text-left leading-tight min-w-0">
          <span className="text-[11px] text-white/85 font-medium truncate">
            {SITE_CONFIG.iosAppName}
          </span>
          <span className="text-sm sm:text-[15px] font-bold text-[#F5F5F5]">
            Download on the App Store
          </span>
        </div>
      </div>
      <ExternalLink className="w-4 h-4 text-white/85 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform shrink-0" />
    </a>
  );
};

interface GooglePlayComingSoonProps {
  variant?: 'default' | 'compact';
  className?: string;
}

export const GooglePlayComingSoonButton: React.FC<GooglePlayComingSoonProps> = ({
  variant = 'default',
  className = '',
}) => {
  if (variant === 'compact') {
    return (
      <button
        type="button"
        disabled
        aria-disabled="true"
        className={`w-full flex items-center justify-between gap-3 px-3.5 py-2.5 rounded-xl bg-[#090A0C] border border-white/[0.08] text-[#A1A1AA] cursor-not-allowed text-left ${className}`}
      >
        <div className="flex items-center gap-2.5 min-w-0">
          <GooglePlayLogoIcon className="w-4 h-4 text-[#A1A1AA] shrink-0" />
          <div className="min-w-0">
            <div className="text-xs font-semibold text-[#F5F5F5] truncate">
              Google Play — Coming Soon
            </div>
            <div className="text-[11px] text-[#A1A1AA] truncate">
              Android app coming soon
            </div>
          </div>
        </div>
      </button>
    );
  }

  return (
    <button
      type="button"
      disabled
      aria-disabled="true"
      className={`inline-flex items-center justify-between gap-3.5 px-5 py-3.5 rounded-xl bg-[#090A0C] border border-white/[0.08] text-[#A1A1AA] cursor-not-allowed text-left ${className}`}
    >
      <div className="flex items-center gap-3 min-w-0">
        <GooglePlayLogoIcon className="w-6 h-6 text-[#A1A1AA] shrink-0" />
        <div className="flex flex-col text-left leading-tight min-w-0">
          <span className="text-[11px] text-[#A1A1AA] font-medium">
            Android
          </span>
          <span className="text-sm sm:text-[15px] font-bold text-[#F5F5F5]">
            Google Play — Coming Soon
          </span>
        </div>
      </div>
      <span className="shrink-0 text-xs font-medium text-[#A1A1AA] whitespace-nowrap">
        Coming Soon
      </span>
    </button>
  );
};
