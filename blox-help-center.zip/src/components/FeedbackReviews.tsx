/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { SITE_CONFIG } from '../config/siteConfig';
import { ExternalLink, AlertCircle } from 'lucide-react';

export const FeedbackReviews: React.FC = () => {
  const [iframeLoaded, setIframeLoaded] = useState(false);
  const [iframeError, setIframeError] = useState(false);

  return (
    <div className="space-y-8 sm:space-y-10 py-8 sm:py-12 max-w-4xl mx-auto">

      {/* Header */}
      <div className="text-center space-y-3">
        <div className="text-xs font-semibold uppercase tracking-[0.14em] text-[#F4510B]">
          Feedback &amp; Reviews
        </div>
        <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-[#F5F5F5] tracking-tight text-balance">
          Your Voice Matters.
        </h1>
        <p className="text-[#A1A1AA] text-base sm:text-lg max-w-2xl mx-auto leading-relaxed">
          Whether you have a review, suggestion or problem to report, we&apos;d love to hear from you.
        </p>

        {/* Direct-Link Fallback Action */}
        <div className="pt-2 flex flex-wrap items-center justify-center gap-3">
          <a
            href={SITE_CONFIG.googleFeedbackFormDirectUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#17191D] hover:bg-white/[0.08] border border-white/[0.08] hover:border-[#F4510B]/40 text-[#F5F5F5] text-xs sm:text-sm font-semibold transition-colors whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#F4510B]"
          >
            <span>Open Feedback Form</span>
            <ExternalLink className="w-3.5 h-3.5 text-[#F4510B]" />
          </a>
        </div>
      </div>

      {/* Responsive Embedded Google Form */}
      <div className="relative w-full rounded-2xl overflow-hidden border border-white/[0.08] bg-[#17191D]">
        {!iframeLoaded && !iframeError && (
          <div className="absolute inset-x-0 top-0 h-64 flex flex-col items-center justify-center gap-3 bg-[#17191D] text-xs sm:text-sm text-[#A1A1AA] pointer-events-none">
            <div className="w-6 h-6 rounded-full border-2 border-[#F4510B] border-t-transparent animate-spin" />
            <span>Loading feedback form…</span>
          </div>
        )}

        {iframeError ? (
          <div className="p-8 sm:p-12 text-center space-y-4">
            <AlertCircle className="w-8 h-8 text-[#F4510B] mx-auto" />
            <div className="space-y-1.5 max-w-md mx-auto">
              <h2 className="text-lg font-bold text-[#F5F5F5]">
                Unable to load the embedded form
              </h2>
              <p className="text-sm text-[#A1A1AA] leading-relaxed">
                Your browser or privacy settings may block embedded third-party forms. Open the official Google Feedback Form directly in a new tab.
              </p>
            </div>
            <div>
              <a
                href={SITE_CONFIG.googleFeedbackFormDirectUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-5 py-3 rounded-xl bg-[#F4510B] hover:bg-[#E04807] text-[#F5F5F5] text-sm font-semibold transition-colors whitespace-nowrap"
              >
                <span>Open Feedback Form</span>
                <ExternalLink className="w-4 h-4" />
              </a>
            </div>
          </div>
        ) : (
          <iframe
            src={SITE_CONFIG.googleFeedbackFormEmbedUrl}
            title={SITE_CONFIG.googleFeedbackFormName}
            loading="lazy"
            width="100%"
            height="1150"
            onLoad={() => setIframeLoaded(true)}
            onError={() => setIframeError(true)}
            className="block w-full min-h-[1000px] h-[1150px] sm:h-[1200px] border-0 bg-white"
          >
            Loading…
          </iframe>
        )}
      </div>

      {/* Subtle Direct Link Footer Note */}
      <div className="text-center text-xs text-[#A1A1AA]">
        Having trouble viewing the embedded form?{' '}
        <a
          href={SITE_CONFIG.googleFeedbackFormDirectUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="text-[#F5F5F5] hover:text-[#F4510B] underline underline-offset-4 transition-colors"
        >
          Open Feedback Form in a new tab
        </a>
        .
      </div>

    </div>
  );
};
