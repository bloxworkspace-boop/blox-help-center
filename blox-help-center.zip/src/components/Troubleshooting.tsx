/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { useBloxConfig, SECTION_HASHES } from '../context/ConfigContext';
import { TROUBLESHOOTING_ISSUES } from '../data/portalData';
import { SITE_CONFIG } from '../config/siteConfig';
import {
  Wrench,
  Radio,
  Settings,
  Lock,
  LogOut,
  HelpCircle,
  Mail,
  Search,
  Check,
  ChevronDown,
} from 'lucide-react';

export const Troubleshooting: React.FC = () => {
  const { setActiveSection, activeTroubleshootingId, setActiveTroubleshootingId } = useBloxConfig();
  const [selectedCategory, setSelectedCategory] = useState<
    'all' | 'nfc' | 'setup' | 'blocking' | 'session' | 'other'
  >('all');
  const [expandedIssueId, setExpandedIssueId] = useState<string | null>('nfc-connection');
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    if (activeTroubleshootingId) {
      setExpandedIssueId(activeTroubleshootingId);
      setSelectedCategory('all');
    }
  }, [activeTroubleshootingId]);

  const categories = [
    { id: 'all', label: 'All Categories', icon: <Wrench className="w-3.5 h-3.5" /> },
    { id: 'nfc', label: 'NFC Connection', icon: <Radio className="w-3.5 h-3.5" /> },
    { id: 'setup', label: 'App Setup', icon: <Settings className="w-3.5 h-3.5" /> },
    { id: 'blocking', label: 'Blocking Functionality', icon: <Lock className="w-3.5 h-3.5" /> },
    { id: 'session', label: 'Ending a Session', icon: <LogOut className="w-3.5 h-3.5" /> },
    { id: 'other', label: 'Other Questions', icon: <HelpCircle className="w-3.5 h-3.5" /> },
  ];

  const filteredIssues = TROUBLESHOOTING_ISSUES.filter((issue) => {
    const matchesCategory =
      selectedCategory === 'all' || issue.category === selectedCategory;
    const matchesSearch =
      searchQuery.trim() === '' ||
      issue.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      issue.summary.toLowerCase().includes(searchQuery.toLowerCase()) ||
      issue.guidance.some((g) => g.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="space-y-12 py-8 sm:py-12 max-w-4xl mx-auto">

      {/* Header */}
      <div className="text-center space-y-3">
        <div className="text-xs font-semibold uppercase tracking-[0.14em] text-[#F4510B]">
          Support Guidance
        </div>
        <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-[#F5F5F5] tracking-tight">
          Troubleshooting
        </h1>
        <p className="text-[#A1A1AA] text-base sm:text-lg max-w-2xl mx-auto">
          Organised topics covering NFC connection, app setup, blocking functionality, ending a session, and other questions.
        </p>
      </div>

      {/* Category Filter & Search */}
      <div className="space-y-4">
        <div className="flex flex-wrap items-center justify-center gap-2">
          {categories.map((cat) => (
            <button
              key={cat.id}
              type="button"
              onClick={() => {
                setActiveTroubleshootingId(null);
                setSelectedCategory(cat.id as typeof selectedCategory);
              }}
              className={`inline-flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap ${
                selectedCategory === cat.id
                  ? 'bg-[#F4510B] text-[#F5F5F5]'
                  : 'bg-[#17191D] text-[#A1A1AA] hover:text-[#F5F5F5] border border-white/[0.08]'
              }`}
            >
              {cat.icon}
              <span>{cat.label}</span>
            </button>
          ))}
        </div>

        <div className="relative max-w-md mx-auto">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#A1A1AA] pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search troubleshooting topics..."
            aria-label="Search troubleshooting topics"
            className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-[#17191D] text-[#F5F5F5] text-sm placeholder-[#A1A1AA] border border-white/[0.08] focus:border-[#F4510B] focus:outline-none transition-colors"
          />
        </div>
      </div>

      {/* Topic List */}
      <div className="space-y-3">
        {filteredIssues.length === 0 ? (
          <div className="text-center py-12 rounded-2xl blox-card space-y-3">
            <Wrench className="w-8 h-8 text-[#A1A1AA] mx-auto" />
            <div className="text-base font-semibold text-[#F5F5F5]">No matching topics found</div>
            <p className="text-xs text-[#A1A1AA] max-w-sm mx-auto">
              Select All Categories or email our support team for direct assistance.
            </p>
          </div>
        ) : (
          filteredIssues.map((issue) => {
            const isExpanded = expandedIssueId === issue.id;
            return (
              <div
                key={issue.id}
                id={`troubleshoot-${issue.id}`}
                className={`rounded-2xl border transition-colors overflow-hidden bg-[#17191D] ${
                  isExpanded
                    ? 'border-[#F4510B]/40'
                    : 'border-white/[0.08] hover:border-white/20'
                }`}
              >
                <button
                  type="button"
                  onClick={() => {
                    setActiveTroubleshootingId(null);
                    setExpandedIssueId(isExpanded ? null : issue.id);
                  }}
                  aria-expanded={isExpanded}
                  className="w-full p-5 sm:p-6 text-left flex items-center justify-between gap-4 focus:outline-none group cursor-pointer"
                >
                  <div className="space-y-1">
                    <h3 className="text-base sm:text-lg font-bold text-[#F5F5F5] group-hover:text-[#F4510B] transition-colors">
                      {issue.title}
                    </h3>
                    <p className="text-xs sm:text-sm text-[#A1A1AA]">{issue.summary}</p>
                  </div>

                  <div
                    className={`w-8 h-8 rounded-lg flex items-center justify-center bg-[#090A0C] border border-white/[0.08] text-[#A1A1AA] group-hover:text-[#F5F5F5] transition-transform duration-200 shrink-0 ${
                      isExpanded ? 'rotate-180 text-[#F5F5F5]' : ''
                    }`}
                  >
                    <ChevronDown className="w-4 h-4" />
                  </div>
                </button>

                {isExpanded && (
                  <div className="px-5 pb-6 sm:px-6 sm:pb-6 pt-4 border-t border-white/[0.08] space-y-5">
                    <ul className="space-y-3">
                      {issue.guidance.map((line, idx) => (
                        <li
                          key={idx}
                          className="text-sm text-[#F5F5F5]/90 flex items-start gap-2.5 leading-relaxed"
                        >
                          <Check className="w-4 h-4 text-[#F4510B] shrink-0 mt-1" />
                          <span>{line}</span>
                        </li>
                      ))}
                    </ul>

                    <div className="pt-4 border-t border-white/[0.08] flex flex-wrap items-center justify-between gap-3">
                      <a
                        href={`mailto:${SITE_CONFIG.supportEmail}`}
                        className="text-xs font-mono text-[#A1A1AA] hover:text-[#F5F5F5] underline underline-offset-4 transition-colors"
                      >
                        {SITE_CONFIG.supportEmail}
                      </a>
                      <a
                        href={`mailto:${SITE_CONFIG.supportEmail}`}
                        className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-[#F4510B] hover:bg-[#E04807] text-[#F5F5F5] text-xs font-semibold transition-colors whitespace-nowrap"
                      >
                        <Mail className="w-3.5 h-3.5" />
                        <span>Contact BLOX Support</span>
                      </a>
                    </div>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>

      {/* Contact BLOX Support Banner */}
      <div className="p-6 sm:p-8 rounded-2xl blox-card flex flex-col md:flex-row items-center justify-between gap-6 text-center md:text-left">
        <div className="space-y-2">
          <div className="text-xs font-semibold uppercase tracking-wider text-[#F4510B]">
            Contact BLOX Support
          </div>
          <h3 className="text-xl sm:text-2xl font-bold text-[#F5F5F5] tracking-tight">
            Still need assistance?
          </h3>
          <p className="text-sm text-[#A1A1AA] max-w-lg">
            If your BLOX device does not activate as expected, or you cannot end your session, email us at{' '}
            <a
              href={`mailto:${SITE_CONFIG.supportEmail}`}
              className="font-mono text-[#F5F5F5] hover:text-[#F4510B] underline underline-offset-4 transition-colors"
            >
              {SITE_CONFIG.supportEmail}
            </a>{' '}
            with a short description of the issue.
          </p>
        </div>

        <div className="flex flex-wrap items-center justify-center gap-3 shrink-0">
          <a
            href={`mailto:${SITE_CONFIG.supportEmail}`}
            className="inline-flex items-center gap-2 px-5 py-3 rounded-xl bg-[#F4510B] hover:bg-[#E04807] text-[#F5F5F5] font-semibold text-sm transition-colors whitespace-nowrap"
          >
            <Mail className="w-4 h-4" />
            <span>Send an Email</span>
          </a>
          <a
            href={SECTION_HASHES.support}
            onClick={(e) => {
              e.preventDefault();
              setActiveSection('support');
            }}
            className="inline-flex items-center gap-2 px-4 py-3 rounded-xl bg-[#090A0C] hover:bg-white/[0.06] text-[#F5F5F5] font-medium text-sm border border-white/[0.08] transition-colors whitespace-nowrap"
          >
            <span>Contact BLOX Support</span>
          </a>
        </div>
      </div>

    </div>
  );
};
