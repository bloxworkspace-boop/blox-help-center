/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { useBloxConfig, NavSection, SECTION_HASHES } from '../context/ConfigContext';
import { SITE_CONFIG } from '../config/siteConfig';
import { BloxLogo } from './BloxLogo';
import {
  AppStoreDownloadButton,
  GooglePlayComingSoonButton,
} from './AppDownloadButtons';
import { ExternalLink, Mail } from 'lucide-react';

export const Footer: React.FC = () => {
  const { setActiveSection } = useBloxConfig();

  const handleNav = (e: React.MouseEvent<HTMLAnchorElement>, section: NavSection) => {
    e.preventDefault();
    setActiveSection(section);
  };

  return (
    <footer className="mt-20 border-t border-white/[0.08] bg-[#090A0C] text-[#A1A1AA] text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14 space-y-12">

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-8 lg:gap-8">

          {/* Brand & Short Description */}
          <div className="lg:col-span-3 space-y-4">
            <div className="flex items-center gap-3">
              <BloxLogo className="w-10 h-10" />
              <div className="flex flex-col leading-none">
                <span className="text-lg font-bold text-[#F5F5F5] tracking-[-0.02em]">BLOX</span>
                <span className="mt-1 text-[10px] font-semibold uppercase tracking-[0.16em] text-[#A1A1AA]">
                  Help Centre
                </span>
              </div>
            </div>

            <p className="text-[#A1A1AA] leading-relaxed text-xs sm:text-sm max-w-xs">
              Public customer support website for BLOX and the Blocks companion app—helping you reduce distractions while keeping useful apps accessible.
            </p>
          </div>

          {/* Navigation Links */}
          <div className="lg:col-span-3 space-y-4">
            <span className="text-[#F5F5F5] text-xs font-semibold uppercase tracking-wider block">
              Help Centre
            </span>
            <ul className="grid grid-cols-2 lg:grid-cols-1 gap-2.5 text-xs">
              <li>
                <a
                  href={SECTION_HASHES.home}
                  onClick={(e) => handleNav(e, 'home')}
                  className="hover:text-[#F5F5F5] transition-colors"
                >
                  Home
                </a>
              </li>
              <li>
                <a
                  href={SECTION_HASHES.walkthrough}
                  onClick={(e) => handleNav(e, 'walkthrough')}
                  className="hover:text-[#F5F5F5] transition-colors"
                >
                  How to Use BLOX
                </a>
              </li>
              <li>
                <a
                  href={SECTION_HASHES.faqs}
                  onClick={(e) => handleNav(e, 'faqs')}
                  className="hover:text-[#F5F5F5] transition-colors"
                >
                  FAQs
                </a>
              </li>
              <li>
                <a
                  href={SECTION_HASHES.troubleshooting}
                  onClick={(e) => handleNav(e, 'troubleshooting')}
                  className="hover:text-[#F5F5F5] transition-colors"
                >
                  Troubleshooting
                </a>
              </li>
              <li>
                <a
                  href={SECTION_HASHES.support}
                  onClick={(e) => handleNav(e, 'support')}
                  className="hover:text-[#F5F5F5] transition-colors"
                >
                  Contact Support
                </a>
              </li>
              <li>
                <a
                  href={SECTION_HASHES.feedback}
                  onClick={(e) => handleNav(e, 'feedback')}
                  className="hover:text-[#F5F5F5] transition-colors"
                >
                  Feedback &amp; Reviews
                </a>
              </li>
            </ul>
          </div>

          {/* Get the App */}
          <div className="lg:col-span-3 space-y-3">
            <span className="text-[#F5F5F5] text-xs font-semibold uppercase tracking-wider block">
              Get the App
            </span>
            <div className="space-y-2.5">
              <AppStoreDownloadButton variant="compact" />
              <GooglePlayComingSoonButton variant="compact" />
            </div>
          </div>

          {/* Support & Official WhatsApp Channel */}
          <div className="lg:col-span-3 space-y-3">
            <span className="text-[#F5F5F5] text-xs font-semibold uppercase tracking-wider block">
              Support &amp; Updates
            </span>

            <a
              href={`mailto:${SITE_CONFIG.supportEmail}`}
              className="w-full flex items-center gap-2.5 px-3.5 py-2.5 rounded-xl bg-[#17191D] hover:bg-white/[0.08] border border-white/[0.08] text-[#F5F5F5] transition-colors"
            >
              <Mail className="w-4 h-4 text-[#F4510B] shrink-0" />
              <span className="text-xs font-mono truncate">{SITE_CONFIG.supportEmail}</span>
            </a>

            <a
              href={SITE_CONFIG.whatsappChannelUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl bg-emerald-600/15 hover:bg-emerald-600/25 border border-emerald-500/30 text-[#F5F5F5] transition-colors"
            >
              <div>
                <div className="font-semibold text-xs text-emerald-300">
                  Follow BLOX on WhatsApp
                </div>
                <div className="text-[11px] text-[#A1A1AA]">Official BLOX WhatsApp Channel</div>
              </div>
              <ExternalLink className="w-3.5 h-3.5 text-emerald-300 shrink-0" />
            </a>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-white/[0.08] flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-[#A1A1AA]">
          <div>
            &copy; {new Date().getFullYear()} BLOX. Official Customer Help Centre.
          </div>
          <div>
            No account required · Public support website
          </div>
        </div>

      </div>
    </footer>
  );
};
