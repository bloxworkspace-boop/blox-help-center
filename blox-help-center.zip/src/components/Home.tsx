/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useBloxConfig, NavSection, SECTION_HASHES } from '../context/ConfigContext';
import { SITE_CONFIG } from '../config/siteConfig';
import {
  AppStoreDownloadButton,
  GooglePlayComingSoonButton,
} from './AppDownloadButtons';
import {
  Compass,
  HelpCircle,
  Wrench,
  Mail,
  MessageSquareText,
  ExternalLink,
  Search,
  ArrowRight,
  Check,
} from 'lucide-react';
import { FAQS, TROUBLESHOOTING_ISSUES, WALKTHROUGH_STEPS } from '../data/portalData';

import heroImg01 from '../assets/images/blox_image_01_hero.jpg';
import handImg02 from '../assets/images/blox_image_02_hand.jpg';

export const Home: React.FC = () => {
  const {
    setActiveSection,
    openWalkthroughStep,
    openFaq,
    openTroubleshootingIssue,
  } = useBloxConfig();

  const [searchQuery, setSearchQuery] = useState('');

  const filteredFaqs = searchQuery.trim()
    ? FAQS.filter(
        (f) =>
          f.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
          f.answer.toLowerCase().includes(searchQuery.toLowerCase()) ||
          f.keywords.some((k) => k.toLowerCase().includes(searchQuery.toLowerCase()))
      )
    : [];

  const filteredIssues = searchQuery.trim()
    ? TROUBLESHOOTING_ISSUES.filter(
        (i) =>
          i.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          i.summary.toLowerCase().includes(searchQuery.toLowerCase()) ||
          i.guidance.some((g) => g.toLowerCase().includes(searchQuery.toLowerCase()))
      )
    : [];

  const filteredSteps = searchQuery.trim()
    ? WALKTHROUGH_STEPS.filter(
        (s) =>
          s.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          s.subtitle.toLowerCase().includes(searchQuery.toLowerCase()) ||
          s.description.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : [];

  const totalResults = filteredFaqs.length + filteredIssues.length + filteredSteps.length;

  const navigateTo = (section: NavSection) => {
    setActiveSection(section);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="space-y-16 sm:space-y-20 py-8 sm:py-12">

      {/* Hero Section */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-center">
        {/* Left Column: Core Message, Search & Primary Actions */}
        <div className="lg:col-span-7 space-y-6">
          <div className="text-xs font-semibold uppercase tracking-[0.14em] text-[#F4510B]">
            BLOX Help Centre · NFC Digital Wellness
          </div>

          <div className="space-y-4">
            <h1 className="text-4xl sm:text-5xl lg:text-[54px] font-extrabold tracking-tight text-[#F5F5F5] leading-[1.08] text-balance">
              Your phone should serve you.{' '}
              <span className="text-[#F4510B]">Not control you.</span>
            </h1>
            <p className="text-base sm:text-lg text-[#F5F5F5]/90 leading-relaxed max-w-2xl">
              BLOX is a physical NFC-based digital-wellness device that helps people stop doom-scrolling and regain control over their phone usage.
            </p>
            <p className="text-sm sm:text-[15px] text-[#A1A1AA] max-w-xl leading-relaxed">
              BLOX uses NFC with the Blocks companion app. Tap your physical BLOX device to activate BLOX Mode—blocking selected distracting apps while useful apps remain accessible—and tap again to end your session.
            </p>
          </div>

          {/* Quick Live Search Bar */}
          <div className="relative max-w-xl pt-1">
            <div className="relative flex items-center">
              <Search className="absolute left-4 w-4 h-4 text-[#A1A1AA] pointer-events-none" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search the user guide, FAQs, or troubleshooting..."
                aria-label="Search BLOX Help Centre"
                className="w-full pl-11 pr-16 py-3.5 rounded-xl bg-[#17191D] text-[#F5F5F5] placeholder-[#A1A1AA] border border-white/[0.08] focus:border-[#F4510B] focus:outline-none transition-colors text-sm sm:text-base"
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 px-2.5 py-1 text-xs text-[#A1A1AA] hover:text-[#F5F5F5] bg-white/[0.06] rounded-md cursor-pointer transition-colors"
                >
                  Clear
                </button>
              )}
            </div>

            {searchQuery.trim().length > 0 && (
              <div className="absolute top-full left-0 right-0 mt-2 p-3 bg-[#17191D] border border-white/[0.08] rounded-2xl shadow-2xl z-40 max-h-96 overflow-y-auto space-y-3">
                <div className="flex items-center justify-between text-xs font-medium px-2 text-[#A1A1AA]">
                  <span>Search Results ({totalResults})</span>
                  <span>Select a result to open</span>
                </div>

                {totalResults === 0 ? (
                  <div className="text-center py-6 text-sm text-[#A1A1AA]">
                    No matches found for &quot;{searchQuery}&quot;. Try searching &quot;NFC&quot;, &quot;Blocks&quot;, or &quot;iPhone&quot;.
                  </div>
                ) : (
                  <>
                    {filteredSteps.length > 0 && (
                      <div className="space-y-1">
                        <span className="text-[11px] uppercase tracking-wider text-[#F4510B] font-semibold px-2">
                          How to Use BLOX
                        </span>
                        {filteredSteps.map((s) => (
                          <button
                            key={s.id}
                            type="button"
                            onClick={() => {
                              setSearchQuery('');
                              openWalkthroughStep(s.id - 1);
                            }}
                            className="w-full text-left p-2.5 rounded-xl hover:bg-white/[0.04] transition flex items-center justify-between group cursor-pointer"
                          >
                            <div>
                              <div className="text-sm font-medium text-[#F5F5F5] group-hover:text-[#F4510B] transition-colors">
                                Step {s.id} — {s.title}
                              </div>
                              <div className="text-xs text-[#A1A1AA] line-clamp-1">{s.subtitle}</div>
                            </div>
                            <span className="text-xs text-[#F4510B] font-medium flex items-center gap-1 shrink-0 ml-2">
                              Open <ArrowRight className="w-3.5 h-3.5" />
                            </span>
                          </button>
                        ))}
                      </div>
                    )}

                    {filteredFaqs.length > 0 && (
                      <div className="space-y-1 pt-2 border-t border-white/[0.08]">
                        <span className="text-[11px] uppercase tracking-wider text-[#F4510B] font-semibold px-2">
                          FAQs
                        </span>
                        {filteredFaqs.map((f) => (
                          <button
                            key={f.id}
                            type="button"
                            onClick={() => {
                              setSearchQuery('');
                              openFaq(f.id);
                            }}
                            className="w-full text-left p-2.5 rounded-xl hover:bg-white/[0.04] transition flex items-center justify-between group cursor-pointer"
                          >
                            <div className="text-sm font-medium text-[#F5F5F5] group-hover:text-[#F4510B] transition-colors">
                              {f.question}
                            </div>
                            <span className="text-xs text-[#F4510B] font-medium flex items-center gap-1 shrink-0 ml-2">
                              Open <ArrowRight className="w-3.5 h-3.5" />
                            </span>
                          </button>
                        ))}
                      </div>
                    )}

                    {filteredIssues.length > 0 && (
                      <div className="space-y-1 pt-2 border-t border-white/[0.08]">
                        <span className="text-[11px] uppercase tracking-wider text-[#F4510B] font-semibold px-2">
                          Troubleshooting
                        </span>
                        {filteredIssues.map((i) => (
                          <button
                            key={i.id}
                            type="button"
                            onClick={() => {
                              setSearchQuery('');
                              openTroubleshootingIssue(i.id);
                            }}
                            className="w-full text-left p-2.5 rounded-xl hover:bg-white/[0.04] transition flex items-center justify-between group cursor-pointer"
                          >
                            <div>
                              <div className="text-sm font-medium text-[#F5F5F5] group-hover:text-[#F4510B] transition-colors">
                                {i.title}
                              </div>
                              <div className="text-xs text-[#A1A1AA] line-clamp-1">{i.summary}</div>
                            </div>
                            <span className="text-xs text-[#F4510B] font-medium flex items-center gap-1 shrink-0 ml-2">
                              Open <ArrowRight className="w-3.5 h-3.5" />
                            </span>
                          </button>
                        ))}
                      </div>
                    )}
                  </>
                )}
              </div>
            )}
          </div>

          {/* Primary & Secondary Actions */}
          <div className="pt-2 flex flex-wrap gap-3">
            <a
              href={SECTION_HASHES.walkthrough}
              onClick={(e) => {
                e.preventDefault();
                navigateTo('walkthrough');
              }}
              className="inline-flex items-center gap-2 px-5 py-3 rounded-xl bg-[#F4510B] hover:bg-[#E04807] text-[#F5F5F5] font-semibold text-sm sm:text-base transition-colors whitespace-nowrap"
            >
              <Compass className="w-4 h-4" />
              <span>Explore the User Guide</span>
            </a>

            <a
              href={SECTION_HASHES.support}
              onClick={(e) => {
                e.preventDefault();
                navigateTo('support');
              }}
              className="inline-flex items-center gap-2 px-5 py-3 rounded-xl bg-[#17191D] hover:bg-white/[0.08] text-[#F5F5F5] font-semibold text-sm sm:text-base border border-white/[0.08] transition-colors whitespace-nowrap"
            >
              <Mail className="w-4 h-4 text-[#F4510B]" />
              <span>Contact Support</span>
            </a>
          </div>
        </div>

        {/* Right Column: Official Physical BLOX Device Photography */}
        <div className="lg:col-span-5 space-y-4">
          <div className="relative rounded-2xl overflow-hidden border border-white/[0.08] bg-[#17191D]">
            <img
              src={heroImg01}
              alt="BLOX orange rounded-square physical NFC device showing centred embossed BLOX wordmark, four curved recessed grooves, and casing seam"
              className="w-full aspect-[1155/960] object-cover"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-12 gap-4 items-stretch">
            <div className="sm:col-span-5 rounded-2xl overflow-hidden border border-white/[0.08] bg-[#17191D]">
              <img
                src={handImg02}
                alt="Physical BLOX orange rounded-square device held in a hand"
                className="w-full h-40 sm:h-full object-cover object-[50%_75%]"
              />
            </div>
            <div className="sm:col-span-7 p-4 rounded-2xl bg-[#17191D] border border-white/[0.08] flex flex-col justify-center space-y-2.5">
              <div className="text-xs font-semibold text-[#F5F5F5]">At a Glance</div>
              <ul className="space-y-2 text-xs text-[#A1A1AA]">
                <li className="flex items-start gap-2">
                  <Check className="w-3.5 h-3.5 text-[#F4510B] shrink-0 mt-0.5" />
                  <span>Physical NFC tap activates and ends BLOX Mode</span>
                </li>
                <li className="flex items-start gap-2">
                  <Check className="w-3.5 h-3.5 text-[#F4510B] shrink-0 mt-0.5" />
                  <span>Useful apps remain accessible</span>
                </li>
                <li className="flex items-start gap-2">
                  <Check className="w-3.5 h-3.5 text-[#F4510B] shrink-0 mt-0.5" />
                  <span>One-time purchase, no subscription</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Official Mobile App Download Section */}
      <section
        aria-labelledby="get-the-blox-app-heading"
        className="pt-10 border-t border-white/[0.08] space-y-6"
      >
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3">
          <div className="space-y-1">
            <h2 id="get-the-blox-app-heading" className="text-2xl sm:text-3xl font-bold text-[#F5F5F5] tracking-tight">
              Get the BLOX App
            </h2>
            <p className="text-sm sm:text-base text-[#A1A1AA]">
              Start building a more focused digital life with BLOX.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* iOS Option */}
          <div className="p-6 sm:p-8 rounded-2xl blox-card flex flex-col justify-between space-y-6">
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs font-medium">
                <span className="text-[#A1A1AA]">iPhone &amp; iOS</span>
                <span className="text-emerald-400 font-semibold">Available on App Store</span>
              </div>
              <h3 className="text-xl font-bold text-[#F5F5F5]">
                {SITE_CONFIG.iosAppName}
              </h3>
              <p className="text-sm text-[#A1A1AA] leading-relaxed">
                Download the official BLOX application from the Apple App Store to use with your physical BLOX device.
              </p>
            </div>
            <AppStoreDownloadButton className="w-full" />
          </div>

          {/* Android Option */}
          <div className="p-6 sm:p-8 rounded-2xl blox-card flex flex-col justify-between space-y-6">
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs font-medium">
                <span className="text-[#A1A1AA]">Android</span>
                <span className="text-[#A1A1AA]">Coming Soon</span>
              </div>
              <h3 className="text-xl font-bold text-[#F5F5F5]">
                Google Play — Coming Soon
              </h3>
              <p className="text-sm text-[#A1A1AA] leading-relaxed">
                The BLOX Android app is coming soon. Stay tuned for updates!
              </p>
            </div>
            <GooglePlayComingSoonButton className="w-full" />
          </div>
        </div>
      </section>

      {/* How BLOX Works — Minimalist Editorial Strip */}
      <section className="pt-10 border-t border-white/[0.08] space-y-8">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3">
          <div className="space-y-1">
            <h2 className="text-2xl sm:text-3xl font-bold text-[#F5F5F5] tracking-tight">
              How BLOX Works
            </h2>
            <p className="text-sm sm:text-base text-[#A1A1AA]">
              Use the Blocks companion app with a straightforward physical NFC tap.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="space-y-2">
            <div className="text-xs font-mono font-semibold text-[#F4510B] tabular-nums">01</div>
            <h3 className="text-lg font-bold text-[#F5F5F5]">NFC Tap Control</h3>
            <p className="text-sm text-[#A1A1AA] leading-relaxed">
              BLOX uses NFC. Tap your physical BLOX device to activate BLOX Mode, and tap again when you are ready to end your session.
            </p>
          </div>

          <div className="space-y-2">
            <div className="text-xs font-mono font-semibold text-[#F4510B] tabular-nums">02</div>
            <h3 className="text-lg font-bold text-[#F5F5F5]">Useful Apps Stay Open</h3>
            <p className="text-sm text-[#A1A1AA] leading-relaxed">
              Selected distracting apps are blocked during BLOX Mode while useful apps remain accessible.
            </p>
          </div>

          <div className="space-y-2">
            <div className="text-xs font-mono font-semibold text-[#F4510B] tabular-nums">03</div>
            <h3 className="text-lg font-bold text-[#F5F5F5]">No Subscription</h3>
            <p className="text-sm text-[#A1A1AA] leading-relaxed">
              BLOX uses a one-time purchase model with the Blocks companion app—no recurring fees.
            </p>
          </div>
        </div>
      </section>

      {/* Help Centre Sections */}
      <section className="pt-10 border-t border-white/[0.08] space-y-6">
        <div className="flex items-center justify-between">
          <h2 className="text-xl sm:text-2xl font-bold text-[#F5F5F5] tracking-tight">
            Explore Help Categories
          </h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          <button
            type="button"
            onClick={() => navigateTo('walkthrough')}
            className="text-left p-6 rounded-2xl blox-card-interactive flex flex-col justify-between min-h-[184px] group cursor-pointer"
          >
            <div className="space-y-2.5">
              <Compass className="w-5 h-5 text-[#A1A1AA] group-hover:text-[#F4510B] transition-colors" />
              <h3 className="text-base font-bold text-[#F5F5F5]">
                How to Use BLOX
              </h3>
              <p className="text-xs text-[#A1A1AA] leading-relaxed">
                Six-step walkthrough from getting the Blocks app to starting and ending sessions.
              </p>
            </div>
            <div className="flex items-center gap-1.5 text-xs font-semibold text-[#F4510B] pt-4">
              <span>Explore the User Guide</span>
              <ArrowRight className="w-3.5 h-3.5 transform group-hover:translate-x-1 transition-transform" />
            </div>
          </button>

          <button
            type="button"
            onClick={() => navigateTo('faqs')}
            className="text-left p-6 rounded-2xl blox-card-interactive flex flex-col justify-between min-h-[184px] group cursor-pointer"
          >
            <div className="space-y-2.5">
              <HelpCircle className="w-5 h-5 text-[#A1A1AA] group-hover:text-[#F4510B] transition-colors" />
              <h3 className="text-base font-bold text-[#F5F5F5]">
                FAQs
              </h3>
              <p className="text-xs text-[#A1A1AA] leading-relaxed">
                Clear answers about BLOX hardware, NFC Mode, the Blocks app, and compatibility.
              </p>
            </div>
            <div className="flex items-center gap-1.5 text-xs font-semibold text-[#F4510B] pt-4">
              <span>View FAQs</span>
              <ArrowRight className="w-3.5 h-3.5 transform group-hover:translate-x-1 transition-transform" />
            </div>
          </button>

          <button
            type="button"
            onClick={() => navigateTo('troubleshooting')}
            className="text-left p-6 rounded-2xl blox-card-interactive flex flex-col justify-between min-h-[184px] group cursor-pointer"
          >
            <div className="space-y-2.5">
              <Wrench className="w-5 h-5 text-[#A1A1AA] group-hover:text-[#F4510B] transition-colors" />
              <h3 className="text-base font-bold text-[#F5F5F5]">
                Troubleshooting
              </h3>
              <p className="text-xs text-[#A1A1AA] leading-relaxed">
                Help topics for NFC connection, app setup, blocking, and ending a session.
              </p>
            </div>
            <div className="flex items-center gap-1.5 text-xs font-semibold text-[#F4510B] pt-4">
              <span>View Topics</span>
              <ArrowRight className="w-3.5 h-3.5 transform group-hover:translate-x-1 transition-transform" />
            </div>
          </button>

          <button
            type="button"
            onClick={() => navigateTo('feedback')}
            className="text-left p-6 rounded-2xl blox-card-interactive flex flex-col justify-between min-h-[184px] group cursor-pointer"
          >
            <div className="space-y-2.5">
              <MessageSquareText className="w-5 h-5 text-[#A1A1AA] group-hover:text-[#F4510B] transition-colors" />
              <h3 className="text-base font-bold text-[#F5F5F5]">
                Feedback &amp; Reviews
              </h3>
              <p className="text-xs text-[#A1A1AA] leading-relaxed">
                Share a review, suggestion, or report a problem with our official feedback form.
              </p>
            </div>
            <div className="flex items-center gap-1.5 text-xs font-semibold text-[#F4510B] pt-4">
              <span>Share Feedback</span>
              <ArrowRight className="w-3.5 h-3.5 transform group-hover:translate-x-1 transition-transform" />
            </div>
          </button>
        </div>
      </section>

      {/* Support & Official WhatsApp Channel */}
      <section className="pt-10 border-t border-white/[0.08] grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="p-6 sm:p-8 rounded-2xl blox-card flex flex-col justify-between space-y-6">
          <div className="space-y-2">
            <div className="text-xs font-semibold uppercase tracking-wider text-[#F4510B]">
              Email Support
            </div>
            <h3 className="text-xl font-bold text-[#F5F5F5]">Contact BLOX Support</h3>
            <p className="text-sm text-[#A1A1AA] leading-relaxed">
              Reach the BLOX Support team directly by email:
            </p>
            <a
              href={`mailto:${SITE_CONFIG.supportEmail}`}
              className="inline-block text-sm font-mono text-[#F5F5F5] hover:text-[#F4510B] underline underline-offset-4 transition-colors"
            >
              {SITE_CONFIG.supportEmail}
            </a>
          </div>

          <div className="flex flex-wrap gap-3">
            <a
              href={`mailto:${SITE_CONFIG.supportEmail}`}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[#F4510B] hover:bg-[#E04807] text-[#F5F5F5] text-xs sm:text-sm font-semibold transition-colors whitespace-nowrap"
            >
              <Mail className="w-4 h-4" />
              <span>Send an Email</span>
            </a>
            <button
              type="button"
              onClick={() => navigateTo('support')}
              className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-[#090A0C] hover:bg-white/[0.06] text-[#F5F5F5] text-xs sm:text-sm font-medium border border-white/[0.08] transition-colors cursor-pointer whitespace-nowrap"
            >
              <span>Contact Support</span>
            </button>
          </div>
        </div>

        <div className="p-6 sm:p-8 rounded-2xl blox-card flex flex-col justify-between space-y-6">
          <div className="space-y-2">
            <div className="text-xs font-semibold uppercase tracking-wider text-emerald-400">
              Updates &amp; Announcements
            </div>
            <h3 className="text-xl font-bold text-[#F5F5F5]">Official BLOX WhatsApp Channel</h3>
            <p className="text-sm text-[#A1A1AA] leading-relaxed">
              Follow BLOX for official announcements, updates and information.
            </p>
          </div>

          <div>
            <a
              href={SITE_CONFIG.whatsappChannelUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs sm:text-sm font-semibold transition-colors whitespace-nowrap"
            >
              <span>Follow BLOX on WhatsApp</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>
        </div>
      </section>

    </div>
  );
};
