/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useBloxConfig } from '../context/ConfigContext';
import { WALKTHROUGH_STEPS } from '../data/portalData';
import {
  AppStoreDownloadButton,
  GooglePlayComingSoonButton,
} from './AppDownloadButtons';
import {
  Check,
  Smartphone,
  Apple,
  ChevronRight,
  ChevronLeft,
} from 'lucide-react';

import heroImg01 from '../assets/images/blox_image_01_hero.jpg';
import handImg02 from '../assets/images/blox_image_02_hand.jpg';

export const Walkthrough: React.FC = () => {
  const { activeWalkthroughStep, setActiveWalkthroughStep } = useBloxConfig();
  const [platformFilter, setPlatformFilter] = useState<'ios' | 'android'>('ios');

  const activeIndex = Math.min(Math.max(activeWalkthroughStep, 0), WALKTHROUGH_STEPS.length - 1);
  const currentStep = WALKTHROUGH_STEPS[activeIndex];

  const showHeroPhoto = activeIndex === 0 || activeIndex === 3 || activeIndex === 5;

  return (
    <div className="space-y-10 py-8 sm:py-12">

      {/* Header */}
      <div className="space-y-4 max-w-3xl">
        <div className="text-xs font-semibold uppercase tracking-[0.14em] text-[#F4510B]">
          User Guide · 6 Steps
        </div>
        <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-[#F5F5F5] tracking-tight">
          How to Use BLOX
        </h1>
        <p className="text-[#A1A1AA] text-base sm:text-lg leading-relaxed">
          Use the Blocks companion app with your physical BLOX device. Tap BLOX using NFC to activate BLOX Mode, keep useful apps accessible, and tap again to end your session.
        </p>

        {/* Platform Selector */}
        <div className="pt-2 flex flex-wrap items-center gap-2" role="group" aria-label="Select platform walkthrough">
          <span className="text-xs text-[#A1A1AA] mr-1 font-medium">Platform:</span>

          <button
            type="button"
            onClick={() => setPlatformFilter('ios')}
            aria-pressed={platformFilter === 'ios'}
            className={`inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#F4510B] ${
              platformFilter === 'ios'
                ? 'bg-[#F4510B] text-[#F5F5F5]'
                : 'bg-[#17191D] text-[#A1A1AA] hover:text-[#F5F5F5] border border-white/[0.08]'
            }`}
          >
            <Apple className="w-3.5 h-3.5" />
            <span>iPhone (iOS)</span>
          </button>

          <button
            type="button"
            onClick={() => setPlatformFilter('android')}
            aria-pressed={platformFilter === 'android'}
            className={`inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#F4510B] ${
              platformFilter === 'android'
                ? 'bg-[#F4510B] text-[#F5F5F5]'
                : 'bg-[#17191D] text-[#A1A1AA] hover:text-[#F5F5F5] border border-white/[0.08]'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>Android</span>
          </button>
        </div>
      </div>

      {/* Android Coming Soon Panel */}
      {platformFilter === 'android' ? (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          <div className="lg:col-span-7 p-6 sm:p-10 rounded-2xl blox-card space-y-6">
            <div className="flex items-center justify-between gap-3">
              <span className="text-xs font-semibold uppercase tracking-[0.14em] text-[#F4510B]">
                Android Availability
              </span>
              <span className="text-xs font-semibold text-[#F4510B]">
                Google Play — Coming Soon
              </span>
            </div>

            <div className="space-y-3">
              <h2 className="text-2xl sm:text-3xl font-bold text-[#F5F5F5] tracking-tight">
                Coming Soon on Android
              </h2>
              <p className="text-sm sm:text-base text-[#A1A1AA] leading-relaxed">
                The BLOX Android app is coming soon to Google Play. We&apos;re working towards bringing the BLOX experience to Android users.
              </p>
            </div>

            <div className="pt-2 space-y-4">
              <GooglePlayComingSoonButton className="w-full sm:w-auto" />

              <div className="pt-4 border-t border-white/[0.08] flex flex-wrap items-center justify-between gap-3">
                <span className="text-xs text-[#A1A1AA]">
                  Using an iPhone? View the complete iOS user guide.
                </span>
                <button
                  type="button"
                  onClick={() => setPlatformFilter('ios')}
                  className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#090A0C] hover:bg-white/[0.06] border border-white/[0.08] text-xs font-semibold text-[#F5F5F5] transition-colors cursor-pointer whitespace-nowrap"
                >
                  <Apple className="w-3.5 h-3.5" />
                  <span>View iPhone (iOS) Walkthrough</span>
                </button>
              </div>
            </div>
          </div>

          <div className="lg:col-span-5 rounded-2xl blox-card p-5 space-y-4">
            <div className="rounded-xl overflow-hidden border border-white/[0.08] bg-[#090A0C]">
              <img
                src={heroImg01}
                alt="BLOX orange rounded-square physical NFC device with embossed BLOX wordmark and recessed grooves"
                className="w-full aspect-[4/3] object-cover"
              />
            </div>
            <p className="text-xs text-[#A1A1AA] leading-relaxed">
              BLOX is designed for Android and iPhone users. Google Play availability for the Android app is coming soon.
            </p>
          </div>
        </div>
      ) : (
        <>
          {/* Stepper Strip (iPhone / iOS) */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
            {WALKTHROUGH_STEPS.map((step, idx) => {
              const isActive = idx === activeIndex;
              const isPast = idx < activeIndex;
              return (
                <button
                  key={step.id}
                  type="button"
                  onClick={() => setActiveWalkthroughStep(idx)}
                  className={`p-3.5 rounded-xl text-left border transition-colors flex flex-col justify-between cursor-pointer ${
                    isActive
                      ? 'bg-[#17191D] border-[#F4510B]'
                      : 'bg-[#17191D]/60 border-white/[0.08] hover:border-white/20'
                  }`}
                >
                  <div className="flex items-center justify-between w-full mb-1.5">
                    <span
                      className={`text-xs font-mono font-semibold tabular-nums ${
                        isActive ? 'text-[#F4510B]' : isPast ? 'text-[#F5F5F5]' : 'text-[#A1A1AA]'
                      }`}
                    >
                      Step {step.stepNumber}
                    </span>
                    {isPast && <Check className="w-3.5 h-3.5 text-emerald-400" />}
                  </div>
                  <div
                    className={`text-xs font-medium line-clamp-2 ${
                      isActive ? 'text-[#F5F5F5] font-semibold' : 'text-[#A1A1AA]'
                    }`}
                  >
                    {step.title}
                  </div>
                </button>
              );
            })}
          </div>

          {/* Main Step Detail Stage */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">

            {/* Left Column: Step Content */}
            <div className="lg:col-span-7 p-6 sm:p-8 rounded-2xl blox-card space-y-6">
              <div className="font-mono text-xs uppercase tracking-widest text-[#F4510B] font-semibold tabular-nums">
                Step {currentStep.stepNumber} of 06
              </div>

              <div className="space-y-2">
                <h2 className="text-2xl sm:text-3xl font-bold text-[#F5F5F5] tracking-tight">
                  Step {currentStep.id} — {currentStep.title}
                </h2>
                <p className="text-sm sm:text-base text-[#A1A1AA] font-medium">
                  {currentStep.subtitle}
                </p>
              </div>

              <p className="text-[#F5F5F5]/90 text-sm sm:text-base leading-relaxed">
                {currentStep.description}
              </p>

              <div className="pt-4 border-t border-white/[0.08] space-y-1">
                <div className="text-xs font-semibold uppercase tracking-wider text-[#F4510B]">
                  Key Principle
                </div>
                <p className="text-sm text-[#F5F5F5] font-medium leading-relaxed">
                  {currentStep.keyTakeaway}
                </p>
              </div>

              {/* iPhone (iOS) Instructions */}
              {currentStep.iosSpecifics && (
                <div className="space-y-3 pt-4 border-t border-white/[0.08]">
                  <div className="flex items-center gap-2 text-xs font-semibold text-[#F5F5F5] uppercase tracking-wider">
                    <Apple className="w-4 h-4 text-[#A1A1AA]" />
                    <span>iPhone (iOS)</span>
                  </div>
                  <ul className="space-y-1 pl-5 list-disc text-sm text-[#A1A1AA]">
                    {currentStep.iosSpecifics.map((item, idx) => (
                      <li key={idx} className="leading-relaxed">{item}</li>
                    ))}
                  </ul>
                  {activeIndex === 0 && (
                    <div className="pt-2 space-y-4">
                      <AppStoreDownloadButton className="w-full sm:w-auto" />
                      <div className="pt-3 border-t border-white/[0.08] space-y-2">
                        <div className="text-xs font-semibold text-[#A1A1AA]">
                          Android Availability
                        </div>
                        <p className="text-xs text-[#A1A1AA]">
                          The BLOX Android app is coming soon to Google Play. Stay tuned for updates!
                        </p>
                        <GooglePlayComingSoonButton variant="compact" className="sm:max-w-xs" />
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Step Navigation Controls */}
              <div className="flex items-center justify-between pt-6 border-t border-white/[0.08]">
                <button
                  type="button"
                  disabled={activeIndex === 0}
                  onClick={() => setActiveWalkthroughStep(Math.max(0, activeIndex - 1))}
                  className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl text-xs font-semibold text-[#F5F5F5] bg-[#090A0C] hover:bg-white/[0.06] border border-white/[0.08] disabled:opacity-35 disabled:pointer-events-none transition-colors cursor-pointer whitespace-nowrap"
                >
                  <ChevronLeft className="w-4 h-4" />
                  <span>Previous Step</span>
                </button>

                <div className="text-xs text-[#A1A1AA] font-medium tabular-nums">
                  Step {activeIndex + 1} of {WALKTHROUGH_STEPS.length}
                </div>

                <button
                  type="button"
                  disabled={activeIndex === WALKTHROUGH_STEPS.length - 1}
                  onClick={() => setActiveWalkthroughStep(Math.min(WALKTHROUGH_STEPS.length - 1, activeIndex + 1))}
                  className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl text-xs font-semibold text-[#F5F5F5] bg-[#F4510B] hover:bg-[#E04807] disabled:opacity-35 disabled:pointer-events-none transition-colors cursor-pointer whitespace-nowrap"
                >
                  <span>Next Step</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Right Column: Official Physical BLOX Device Photography */}
            <div className="lg:col-span-5 rounded-2xl blox-card p-5 space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-white/[0.08]">
                <span className="text-xs font-semibold text-[#F5F5F5] uppercase tracking-wider">
                  Physical BLOX Device
                </span>
                <span className="text-xs font-mono text-[#A1A1AA] tabular-nums">
                  Step {currentStep.stepNumber}
                </span>
              </div>

              <div className="rounded-xl overflow-hidden border border-white/[0.08] bg-[#090A0C]">
                <img
                  src={showHeroPhoto ? heroImg01 : handImg02}
                  alt={
                    showHeroPhoto
                      ? 'BLOX orange rounded-square physical NFC device with embossed BLOX wordmark and recessed grooves'
                      : 'Physical BLOX orange rounded-square device held in a hand'
                  }
                  className="w-full aspect-[4/3] object-cover"
                />
              </div>

              <p className="text-xs text-[#A1A1AA] leading-relaxed">
                {activeIndex === 3
                  ? 'Tap your phone against the physical BLOX device to activate BLOX Mode.'
                  : activeIndex === 5
                  ? 'Tap your physical BLOX device again to end your BLOX session.'
                  : 'Use the Blocks companion application together with your physical BLOX NFC device.'}
              </p>
            </div>

          </div>
        </>
      )}

    </div>
  );
};
