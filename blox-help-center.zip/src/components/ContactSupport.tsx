/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef } from 'react';
import { useBloxConfig, SECTION_HASHES } from '../context/ConfigContext';
import { SITE_CONFIG } from '../config/siteConfig';
import {
  Mail,
  Copy,
  Check,
  ExternalLink,
  ChevronRight,
  AlertCircle,
} from 'lucide-react';

const WhatsAppIcon: React.FC<{ className?: string }> = ({ className = 'w-6 h-6' }) => (
  <svg
    className={className}
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    aria-hidden="true"
  >
    <path d="M3 21l1.65-3.8a9 9 0 1 1 3.4 2.9L3 21" />
    <path d="M9 10a.5.5 0 0 0 1 0V9a.5.5 0 0 0-1 0v1a5 5 0 0 0 5 5h1a.5.5 0 0 0 0-1h-1a.5.5 0 0 0 0 1" />
  </svg>
);

export const ContactSupport: React.FC = () => {
  const { setActiveSection } = useBloxConfig();
  const [copyState, setCopyState] = useState<'idle' | 'copied' | 'fallback'>('idle');
  const fallbackInputRef = useRef<HTMLInputElement>(null);

  const handleCopyEmail = async () => {
    try {
      if (!navigator.clipboard || typeof navigator.clipboard.writeText !== 'function') {
        throw new Error('Clipboard API unavailable');
      }
      await navigator.clipboard.writeText(SITE_CONFIG.supportEmail);
      setCopyState('copied');
      setTimeout(() => {
        setCopyState((prev) => (prev === 'copied' ? 'idle' : prev));
      }, 3000);
    } catch {
      setCopyState('fallback');
      requestAnimationFrame(() => {
        fallbackInputRef.current?.focus();
        fallbackInputRef.current?.select();
      });
    }
  };

  return (
    <div className="space-y-12 py-8 sm:py-12 max-w-4xl mx-auto">

      {/* Header */}
      <div className="text-center space-y-3">
        <div className="text-xs font-semibold uppercase tracking-[0.14em] text-[#F4510B]">
          Support &amp; Updates
        </div>
        <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-[#F5F5F5] tracking-tight">
          Contact Support
        </h1>
        <p className="text-[#A1A1AA] text-base sm:text-lg max-w-2xl mx-auto">
          Email the BLOX Support team for product assistance, or follow our official WhatsApp Channel for announcements and updates.
        </p>
      </div>

      {/* Separated Email Support & WhatsApp Channel Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">

        {/* Card 1 — Contact BLOX Support */}
        <div className="blox-card rounded-2xl p-6 sm:p-8 flex flex-col justify-between space-y-6">
          <div className="space-y-4">
            <div className="w-11 h-11 rounded-xl bg-[#F4510B]/10 border border-[#F4510B]/20 flex items-center justify-center text-[#F4510B]">
              <Mail className="w-5 h-5" />
            </div>

            <div className="space-y-1.5">
              <h2 className="text-xl font-bold text-[#F5F5F5]">Contact BLOX Support</h2>
              <p className="text-sm text-[#A1A1AA] leading-relaxed">
                Send an email directly for assistance with your BLOX device or the Blocks companion app.
              </p>
            </div>

            <div className="space-y-2.5 pt-2 border-t border-white/[0.08]">
              <div className="flex items-center justify-between gap-3">
                <a
                  href={`mailto:${SITE_CONFIG.supportEmail}`}
                  className="text-sm font-mono text-[#F5F5F5] hover:text-[#F4510B] transition-colors truncate"
                >
                  {SITE_CONFIG.supportEmail}
                </a>
                <button
                  type="button"
                  onClick={handleCopyEmail}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#090A0C] hover:bg-white/[0.08] border border-white/[0.08] text-xs font-medium text-[#F5F5F5] transition-colors cursor-pointer shrink-0 whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#F4510B]"
                  aria-label="Copy BLOX support email address"
                >
                  {copyState === 'copied' ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Copied</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5 text-[#A1A1AA]" />
                      <span>Copy Email</span>
                    </>
                  )}
                </button>
              </div>

              {copyState === 'copied' && (
                <div role="status" className="text-xs text-emerald-400 font-medium">
                  Email address copied.
                </div>
              )}

              {copyState === 'fallback' && (
                <div className="p-3 rounded-xl bg-[#090A0C] border border-white/[0.08] space-y-2">
                  <div className="flex items-start gap-2 text-xs text-[#A1A1AA]">
                    <AlertCircle className="w-4 h-4 text-[#F4510B] shrink-0 mt-0.5" />
                    <span>
                      Automatic copying is unavailable in this browser. Select and copy the email address below:
                    </span>
                  </div>
                  <input
                    ref={fallbackInputRef}
                    type="text"
                    readOnly
                    value={SITE_CONFIG.supportEmail}
                    onClick={(e) => e.currentTarget.select()}
                    aria-label="Selectable BLOX support email address"
                    className="w-full px-3 py-2 rounded-lg bg-[#17191D] border border-white/[0.12] text-xs font-mono text-[#F5F5F5] focus:border-[#F4510B] focus:outline-none select-all"
                  />
                </div>
              )}
            </div>
          </div>

          <a
            href={`mailto:${SITE_CONFIG.supportEmail}`}
            className="w-full py-3.5 px-5 rounded-xl bg-[#F4510B] hover:bg-[#E04807] text-[#F5F5F5] text-sm font-semibold flex items-center justify-center gap-2 transition-colors whitespace-nowrap"
          >
            <Mail className="w-4 h-4" />
            <span>Send an Email</span>
          </a>
        </div>

        {/* Card 2 — Official BLOX WhatsApp Channel */}
        <div className="blox-card rounded-2xl p-6 sm:p-8 flex flex-col justify-between space-y-6">
          <div className="space-y-4">
            <div className="w-11 h-11 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
              <WhatsAppIcon className="w-5 h-5" />
            </div>

            <div className="space-y-1.5">
              <h2 className="text-xl font-bold text-[#F5F5F5]">Official BLOX WhatsApp Channel</h2>
              <p className="text-sm text-[#A1A1AA] leading-relaxed">
                Follow BLOX for official announcements, updates and information.
              </p>
            </div>
          </div>

          <a
            href={SITE_CONFIG.whatsappChannelUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full py-3.5 px-5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-sm font-semibold flex items-center justify-center gap-2 transition-colors whitespace-nowrap"
          >
            <WhatsAppIcon className="w-4 h-4" />
            <span>Follow BLOX on WhatsApp</span>
            <ExternalLink className="w-3.5 h-3.5 opacity-85" />
          </a>
        </div>

      </div>

      {/* Feedback Link Row */}
      <div className="pt-6 border-t border-white/[0.08] flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="space-y-0.5">
          <span className="text-sm font-semibold text-[#F5F5F5] block">
            Looking for Feedback &amp; Reviews?
          </span>
          <span className="text-xs text-[#A1A1AA]">
            Your feedback helps us make BLOX better.
          </span>
        </div>
        <a
          href={SECTION_HASHES.feedback}
          onClick={(e) => {
            e.preventDefault();
            setActiveSection('feedback');
          }}
          className="shrink-0 inline-flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-xl bg-[#17191D] hover:bg-white/[0.08] border border-white/[0.08] text-[#F5F5F5] text-xs font-semibold transition-colors whitespace-nowrap"
        >
          <span>Feedback &amp; Reviews</span>
          <ChevronRight className="w-3.5 h-3.5" />
        </a>
      </div>

    </div>
  );
};
