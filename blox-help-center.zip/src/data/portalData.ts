/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { WalkthroughStep, FaqItem, TroubleshootingIssue } from '../types';

export const WALKTHROUGH_STEPS: WalkthroughStep[] = [
  {
    id: 1,
    stepNumber: '01',
    title: 'Get the Blocks App',
    subtitle: 'iPhone available on the App Store · Android coming soon',
    description:
      'Download the Blocks companion application to get started with your physical BLOX device.',
    keyTakeaway:
      'iOS users can download BLOX: Stop Doomscrolling from the official Apple App Store link. Android Google Play availability is coming soon.',
    platforms: ['ios', 'android'],
    iosSpecifics: [
      'iPhone users can download BLOX: Stop Doomscrolling directly from the Apple App Store.',
    ],
    androidSpecifics: [
      'The BLOX Android app is coming soon to Google Play.',
    ],
  },
  {
    id: 2,
    stepNumber: '02',
    title: 'Set Up Your Experience',
    subtitle: 'Use the Blocks companion app with your physical BLOX device',
    description:
      'Open the Blocks companion application on your phone to use it together with your physical BLOX NFC device.',
    keyTakeaway:
      'Use the Blocks companion app with your physical BLOX NFC device.',
    platforms: ['ios'],
    iosSpecifics: [
      'Use the Blocks companion app on your iPhone alongside your physical BLOX device.',
    ],
  },
  {
    id: 3,
    stepNumber: '03',
    title: 'Choose Your Distractions',
    subtitle: 'Selected distracting apps are blocked while useful apps remain accessible',
    description:
      'Choose which distracting apps are blocked during BLOX Mode while keeping useful apps accessible.',
    keyTakeaway:
      'Selected distracting apps are blocked while useful apps remain accessible.',
    platforms: ['ios'],
    iosSpecifics: [
      'Select the distracting apps to block on your iPhone while useful apps remain accessible.',
    ],
  },
  {
    id: 4,
    stepNumber: '04',
    title: 'Tap Your BLOX Device',
    subtitle: 'Physical NFC tap activates BLOX Mode',
    description:
      'BLOX uses NFC technology. Tap your phone against your physical BLOX device to activate BLOX Mode.',
    keyTakeaway:
      'Tapping the physical BLOX device using NFC activates BLOX Mode.',
    platforms: ['ios'],
    iosSpecifics: [
      'Tap your iPhone against the physical BLOX device to activate BLOX Mode.',
    ],
  },
  {
    id: 5,
    stepNumber: '05',
    title: 'Stay Focused',
    subtitle: 'Distracting apps remain blocked while useful apps stay accessible',
    description:
      'While BLOX Mode is active, your selected distracting apps remain blocked and useful apps remain accessible so you can focus.',
    keyTakeaway:
      'Selected distracting apps are blocked while useful apps remain accessible.',
    platforms: ['ios'],
    iosSpecifics: [
      'Stay focused on your iPhone while selected distracting apps remain blocked and useful apps stay open.',
    ],
  },
  {
    id: 6,
    stepNumber: '06',
    title: 'End Your Session',
    subtitle: 'Tap your physical BLOX device again to end the session',
    description:
      'When you are ready to finish BLOX Mode, tap your physical BLOX device again to end the session.',
    keyTakeaway:
      'Tap the physical BLOX device again to end the session.',
    platforms: ['ios'],
    iosSpecifics: [
      'Tap your iPhone against your physical BLOX device again to end the session.',
    ],
  },
];

export const FAQS: FaqItem[] = [
  {
    id: 'what-is-blox',
    category: 'general',
    question: 'What is BLOX?',
    answer:
      'BLOX is a physical NFC-based digital-wellness device designed to help people reduce distracting smartphone usage and regain control over their time.',
    keywords: ['what is blox', 'overview', 'device', 'physical', 'nfc', 'digital wellness'],
  },
  {
    id: 'how-blox-works',
    category: 'general',
    question: 'How does BLOX work?',
    answer:
      'Tap your physical BLOX device to activate BLOX Mode. Selected distracting apps are blocked while useful apps remain accessible. Tap again to end the session.',
    keywords: ['how it works', 'nfc', 'tap', 'blox mode', 'end session'],
  },
  {
    id: 'what-is-blocks-app',
    category: 'app',
    question: 'What is the Blocks app?',
    answer:
      'Blocks is the companion mobile application used with the physical BLOX device.',
    keywords: ['blocks', 'companion app', 'mobile application'],
  },
  {
    id: 'does-blox-support-iphone',
    category: 'app',
    question: 'Does BLOX support iPhone?',
    answer:
      'Yes. The BLOX application is available on the Apple App Store.',
    keywords: ['iphone', 'ios', 'apple', 'app store', 'download'],
    appStoreLinkLabel: 'Download on the App Store',
  },
  {
    id: 'does-blox-support-android',
    category: 'app',
    question: 'Does BLOX support Android?',
    answer:
      'BLOX is designed for Android and iPhone users. Google Play availability for the Android application is coming soon.',
    keywords: ['android', 'google play', 'coming soon', 'availability'],
  },
  {
    id: 'where-to-download-blox',
    category: 'app',
    question: 'Where can I download the BLOX app?',
    answer:
      'The iOS application is available on the Apple App Store. The Android application will be available on Google Play soon.',
    keywords: ['download', 'app store', 'google play', 'ios', 'android', 'install'],
    appStoreLinkLabel: 'Download on the App Store',
  },
  {
    id: 'useful-apps-accessible',
    category: 'sessions',
    question: 'Are useful apps still accessible during BLOX Mode?',
    answer:
      'Yes. Selected distracting apps are blocked while useful apps remain accessible.',
    keywords: ['useful apps', 'accessible', 'blocked apps', 'focus'],
  },
  {
    id: 'how-to-end-session',
    category: 'sessions',
    question: 'How do I end a BLOX session?',
    answer:
      'Tap your physical BLOX device again to end the session.',
    keywords: ['end', 'stop', 'session', 'tap again'],
  },
  {
    id: 'subscription-model',
    category: 'general',
    question: 'Does BLOX require a subscription?',
    answer:
      'BLOX uses a one-time purchase model. There is no subscription.',
    keywords: ['subscription', 'one-time purchase', 'pricing', 'cost'],
  },
  {
    id: 'how-to-contact-blox',
    category: 'support',
    question: 'How can I contact BLOX?',
    answer:
      'Contact the BLOX Support team through blox.workspace@gmail.com.',
    keywords: ['help', 'assistance', 'support', 'contact', 'email'],
    includeEmailAction: true,
  },
];

export const TROUBLESHOOTING_ISSUES: TroubleshootingIssue[] = [
  {
    id: 'nfc-connection',
    category: 'nfc',
    title: 'NFC Connection',
    summary: 'Assistance when tapping your physical BLOX device does not respond as expected.',
    guidance: [
      'BLOX uses NFC technology with the Blocks companion application to activate and end BLOX Mode.',
      'Having trouble activating BLOX? If your device does not respond as expected, contact the BLOX Support team so we can help.',
    ],
  },
  {
    id: 'app-setup',
    category: 'setup',
    title: 'App Setup',
    summary: 'Information on using the Blocks companion application with BLOX.',
    guidance: [
      'Use the Blocks companion app with your physical BLOX device.',
      'iPhone users can download BLOX: Stop Doomscrolling directly from the Apple App Store. Google Play availability for Android is coming soon.',
      'If you experience any issue getting started, contact the BLOX Support team at blox.workspace@gmail.com.',
    ],
  },
  {
    id: 'blocking-functionality',
    category: 'blocking',
    title: 'Blocking Functionality',
    summary: 'How blocked distracting apps and useful apps work during BLOX Mode.',
    guidance: [
      'During BLOX Mode, selected distracting apps are blocked while useful apps remain accessible.',
      'If app blocking does not behave as expected, contact the BLOX Support team with a short description of what happened.',
    ],
  },
  {
    id: 'session-ending',
    category: 'session',
    title: 'Ending a Session',
    summary: 'How to finish an active BLOX Mode session.',
    guidance: [
      'Tap your physical BLOX device again to end the session.',
      'Having trouble ending your BLOX session? If your device does not respond as expected, contact the BLOX Support team so we can help.',
    ],
  },
  {
    id: 'other-questions',
    category: 'other',
    title: 'Other Questions',
    summary: 'Additional help for your BLOX device or companion app.',
    guidance: [
      'Battery and charging are optimised for BLOX, and BLOX uses a one-time purchase model with no subscription.',
      'If you have another question, contact the BLOX Support team at blox.workspace@gmail.com.',
    ],
  },
];
