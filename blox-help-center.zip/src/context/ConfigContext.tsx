/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';

export type NavSection =
  | 'home'
  | 'walkthrough'
  | 'faqs'
  | 'troubleshooting'
  | 'support'
  | 'feedback';

export const SECTION_HASHES: Record<NavSection, string> = {
  home: '#home',
  walkthrough: '#how-to-use',
  faqs: '#faqs',
  troubleshooting: '#troubleshooting',
  support: '#contact-support',
  feedback: '#feedback',
};

const HASH_TO_SECTION: Record<string, NavSection> = {
  '#home': 'home',
  '#how-to-use': 'walkthrough',
  '#faqs': 'faqs',
  '#troubleshooting': 'troubleshooting',
  '#contact-support': 'support',
  '#feedback': 'feedback',
};

export function parseSectionFromHash(hash: string): NavSection {
  if (!hash) return 'home';
  const normalized = hash.trim().toLowerCase().replace(/\/+$/, '');
  return HASH_TO_SECTION[normalized] ?? 'home';
}

function getScrollBehavior(): ScrollBehavior {
  if (
    typeof window !== 'undefined' &&
    window.matchMedia('(prefers-reduced-motion: reduce)').matches
  ) {
    return 'auto';
  }
  return 'smooth';
}

export function scrollPageToTop(): void {
  if (typeof window === 'undefined') return;
  window.scrollTo({ top: 0, behavior: getScrollBehavior() });
}

interface PortalContextType {
  activeSection: NavSection;
  setActiveSection: (section: NavSection, options?: { scroll?: boolean }) => void;
  activeWalkthroughStep: number;
  setActiveWalkthroughStep: (stepIndex: number) => void;
  activeFaqId: string | null;
  setActiveFaqId: (id: string | null) => void;
  activeTroubleshootingId: string | null;
  setActiveTroubleshootingId: (id: string | null) => void;
  openWalkthroughStep: (stepIndex: number) => void;
  openFaq: (faqId: string) => void;
  openTroubleshootingIssue: (issueId: string) => void;
}

const PortalContext = createContext<PortalContextType | undefined>(undefined);

export const ConfigProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [activeSection, setActiveSectionState] = useState<NavSection>(() => {
    if (typeof window === 'undefined') return 'home';
    return parseSectionFromHash(window.location.hash);
  });
  const [activeWalkthroughStep, setActiveWalkthroughStep] = useState<number>(0);
  const [activeFaqId, setActiveFaqId] = useState<string | null>(null);
  const [activeTroubleshootingId, setActiveTroubleshootingId] = useState<string | null>(null);

  // Synchronize React state with browser Back / Forward and manual hash edits
  useEffect(() => {
    const handleHashChange = () => {
      const nextSection = parseSectionFromHash(window.location.hash);
      setActiveSectionState(nextSection);
      scrollPageToTop();
    };

    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  const navigateToSection = useCallback(
    (section: NavSection, options: { scroll?: boolean } = { scroll: true }) => {
      const targetHash = SECTION_HASHES[section];
      setActiveSectionState(section);

      if (typeof window !== 'undefined') {
        const currentNormalized = window.location.hash.trim().toLowerCase().replace(/\/+$/, '');
        if (currentNormalized !== targetHash) {
          window.location.hash = targetHash;
        }
      }

      if (options.scroll !== false) {
        scrollPageToTop();
      }
    },
    []
  );

  const openWalkthroughStep = useCallback(
    (stepIndex: number) => {
      setActiveWalkthroughStep(stepIndex);
      navigateToSection('walkthrough');
    },
    [navigateToSection]
  );

  const openFaq = useCallback(
    (faqId: string) => {
      setActiveFaqId(faqId);
      navigateToSection('faqs', { scroll: false });
      setTimeout(() => {
        const el = document.getElementById(`faq-${faqId}`);
        if (el) {
          el.scrollIntoView({ behavior: getScrollBehavior(), block: 'center' });
        }
      }, 100);
    },
    [navigateToSection]
  );

  const openTroubleshootingIssue = useCallback(
    (issueId: string) => {
      setActiveTroubleshootingId(issueId);
      navigateToSection('troubleshooting', { scroll: false });
      setTimeout(() => {
        const el = document.getElementById(`troubleshoot-${issueId}`);
        if (el) {
          el.scrollIntoView({ behavior: getScrollBehavior(), block: 'center' });
        }
      }, 100);
    },
    [navigateToSection]
  );

  return (
    <PortalContext.Provider
      value={{
        activeSection,
        setActiveSection: navigateToSection,
        activeWalkthroughStep,
        setActiveWalkthroughStep,
        activeFaqId,
        setActiveFaqId,
        activeTroubleshootingId,
        setActiveTroubleshootingId,
        openWalkthroughStep,
        openFaq,
        openTroubleshootingIssue,
      }}
    >
      {children}
    </PortalContext.Provider>
  );
};

export const useBloxConfig = (): PortalContextType => {
  const context = useContext(PortalContext);
  if (!context) {
    throw new Error('useBloxConfig must be used within a ConfigProvider');
  }
  return context;
};
