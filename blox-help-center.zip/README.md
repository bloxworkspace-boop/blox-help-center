# BLOX Help Centre

Official standalone customer-facing support website for **BLOX** and the **Blocks** companion application.

## Overview

The BLOX Help Centre is a public, authentication-free React + TypeScript web application built with Vite and Tailwind CSS. Customers can browse resources immediately without creating an account:

- **Home** (`#home`) — Core product overview, live search across help topics, and mobile app availability.
- **How to Use BLOX** (`#how-to-use`) — Six-step iOS walkthrough with official Apple App Store download and Android Coming Soon status.
- **FAQs** (`#faqs`) — Searchable, collapsible product questions and answers.
- **Troubleshooting** (`#troubleshooting`) — Organised guidance categories with direct email support links.
- **Contact Support** (`#contact-support`) — Official email (`blox.workspace@gmail.com`) with clipboard fallback and official WhatsApp Channel announcements link.
- **Feedback & Reviews** (`#feedback`) — Embedded public Google Feedback Form with a direct responder link fallback.

## Getting Started

### Prerequisites

- Node.js (v20+ recommended) or Bun

### Installation & Development

```bash
npm install
npm run dev
```

The development server runs at `http://localhost:3000`.

### Build & Type Check

```bash
npm run lint     # Run TypeScript checks (tsc --noEmit)
npm run build    # Build production static bundle into dist/
npm run preview  # Preview the production build locally
```

## Configuration

Official public links and constants are centralised in `src/config/siteConfig.ts` and can optionally be overridden via Vite environment variables (see `.env.example`):

- `VITE_BLOX_SUPPORT_EMAIL` — Official support email address (`blox.workspace@gmail.com`)
- `VITE_BLOX_WHATSAPP_CHANNEL_URL` — Official WhatsApp Channel URL
- `VITE_BLOX_FEEDBACK_FORM_URL` / `VITE_BLOX_FEEDBACK_FORM_EMBED_URL` — Reserved for future Google Feedback Form integration

Do not place private credentials or secrets in client-side `VITE_*` variables.
